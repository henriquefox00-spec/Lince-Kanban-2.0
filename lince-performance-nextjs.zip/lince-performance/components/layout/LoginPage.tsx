'use client';

import { useState } from 'react';
import { motion } from 'motion/react';
import { AlertCircle, Eye, EyeOff } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useRouter } from 'next/navigation';
import type { Collaborator } from '@/lib/types';

const LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaMAAAB4CAMAAABoxW2eAAAAilBMVEX////uM2PtGVb73eTtI1ruL2HuKF3wUXf0iqH1na/3r736z9jtHVjuK1/3rbz+9vjyc4/5x9H4u8j96+/2prfxXYD71d3xY4P5ws7tEFPvP2v+8fT84ujydZHsAEjsAEzvR3HzgJn1lqr1mq30j6XzhJzxYYLvRW/2orPwWHzxaojsAEL4tsTuOWjwcXuTAAANDklEQVR4nO2d2ZqyvBJGIUK0FZxQNAKO2A7d3v/tbWZRoTIQ+P5+dt6jHjSBLEgqVZVE0/61rpt9rMvmQ9Ff+/3b9+o+DQYjajn+dVGv64zjivzZ8GsQrG7xZfW/p+fjeN2biN9gcw0X43otXPGCPYeu+HNfhhlL/5SZy7YxWdHqmxFcL3Rmu2h3ETwIsgxs26XKDQsRvDrOPOrXx0PpGjva3jLqRcZst1alFUEUkU38uS9cgedT+EF5lGcW9O0B/YL9xTdChl31tMSysUUuIfw+j3ZAYwpq52r9umuKZTRgNLVpzW72488xMtLtPlxfM0b+14YY9CvGyAigbtNguxceWX+IkW59gfU1YTS/EQy1Q1k2so9OXUF36k1z608x0okP1SfOaGFbrIDS68Zk2qspSv6L9LcYmXuoPlFGC2xwEUpkk1UlpR7iLoqmv8VIt67SGc10vneokE2CKiMGuggx/RtG+T+4GYG9nQijyZ2IEUrKRMPPEr+lD0j/hJF1zv7Dz8gEbDsBRmurWYui5ceM6cpxN2z6F4yMg5bNWPkZ6dZCIqMB4ai5Urb1boiPpHd2/4ARvmvaTZiRTmrNXm5GNwk2mElOr4V6jbm/q2NGUVX2Le5isl8FGMXfl8LIe8jplVDwWu5DfICrVqeMTHQ37U3UmLv8DwKMdKvukvgYeaaswd1YvhQcyDYaumRk7Xs3G3uaux1kA6sQIx3VeDa5GHm1bjl+4RdDRvostk1GdwvH3uP8RqLnf4qRr/m7aY5FjJG9rK6Pi9FD5tOOy1ck3Whok9H86xQeVhsDWYZtk8NEO1pkpDlxkOHUhJGOfhszusntkIzps2jpRkObjHI5s+uq70aWAiG/mmfFY342QRJkpFuVUQoORmfZ/REqWXd/qa97k4+sUJvY+5hK5tQSZWTfmzFaS7ePdfKMK8n2NHTI6GFELft4RD+Fu0dauigjHa2bMPLk+9R00yje7YFkT0N3jKZGhGdvR3dy/pldxOew6ReNit6OmdFKfownqqAYkoaSO7vOGM0JcrRbbDZPtzOtYV8XtUjwWQUro7X88EEsknuFZBt2XTGaWMZCW8V+nNXO1dzGjJ4tws9Il+0ISGU+svIdyc9AV4y8HcY3y4+MXtLTtHHWGzRgZJqijNjnmHFKkM0+1y0cIH+UkeYdSDzT26M4ALTMqmzASMcfyViMjNgQ2QZCZv8+nX5vLETPRYlVPDagx46WK/WpbXd23cww9n0zGpDmWDzGVxJ5T/1jY8TyGpkGWi7cwizx54HBEqy1srk1ZHzjCb+0zhhp3gWjnuZ8b297jY0YFf0/H6PKZMvXgtF++GE2zvuI/sVL+tkDcEOoNrQCqTNGUVX4stht/IGU90g3wtfSmRitqUaXsanOnxtdqG8gSl/tE3BDFj0nuqrhumOk7TG6lsbUZox08pqZw8SImv9GjrVXf6LlPmRj5C8A06hIgaCrS0YTEx8Kq64xo7dULhZGE4oXyKyw6Z9yaaMSpl4IDoHya9UlI80n6HdfVNiQ0VsqFwsj6BGPhWpSGzM5lGRWlPRkLmB829SlBVXqlJE2L+fsNmX0mtzAwojS1YFvUSwHfpNw0lFCk1hTF2m1bhlpQYlIY0YvyQ0sjODppVE/FuUagZ1lekNgh4pEFjJ1zGgi8z3Sy1mIDIygXuhpO4MKwd6SJASgWozFnFHrmZtnBXTMqOy6Z2FEscNKyQ0MjOAJLGJa6wd7ERLrG7whw2IWIlmgrGtGpWeZgRGmePpLYzADIzBnB874LzQH35KkveSlb2X9RNeMSn5nBkaWu4BnnWiel8vA6ALeK+PUpQ+5epIZ0l4aIzuNwXTOKCyYsDAawRdYCvcxMAKHI0Jd7ZrKQYZh1Cy7NZI7ukljZKZGUeeMXB4/Q8TIh+edRbiPzgiM7EDp/q/yF4vr1+l0PIZhOAgLpT/GH5AX6M363/YZrVdki6ZPR9WDw6ca+7eucG+XT2rojECzTswDUCl5Cy4zU7NtRpP+zpjPfq3tKu+UjjkURkaU/j2P29AZgZ8Q86RVSl46sZmsvG+d0WYT7qJ3gax1PYNUrEdkZUTr7VJXJp3RHPrExyoVcR3+GKNBNKY72unmV5uYecpt3tmxMtK+YAM8DffRGYHeOtRgu5A3/TFGDlnNZuPHNraQez+ZnXzOqDAzgo3mLNxHZwTOtf5/Gd0f++0WnVPf5xmlfxyy55xkjHpwb5eE+9R7JKjlS9wRpcGEPAONnRHFTZb0dg0Z/TfHo31SYJfzo2k6l+mx59cVsWXYv2Jij4ERGCiXeKsSGaWTtu4YeT184GPbzhdgBAcFdFP3wPzQhBH8CcaduRgk0fbu1M+wDkxCENluN0dHhBGYbROXZYegbzZm5MvxM2i+OxqNZpHWH0o6TPruIazKVoh0wcgLyfb+je6TiTM6PbZ9XText/u7Labw5TRVEUbaSWxlfc7oSvv6x4Z0ucaIarAY6aMIhXtxTemwYEYNgvz3Q/bDpHSQwIvXTYQRJdxX2zYZI9rilvie8fUzi2v+YBgJsz1yoGxYa/5RNINARuYtmHLqnluM4TaNFvVKqyLnL00kxIg2pFSrWGtJcc0ml2WQ+7yMyQ2ZNgDP64Ccu0JmHS3F0ObVc1es8dYMh9flzzJ5vJzL7N12FmJEC/dVq2DENqDZBnkEp+F8PR+HKwOx7aGf+ykgn5XQsgmJzqVUxnPnMufYt0l+PMOYBO8OYTFGQptgPNf+swZ3zPi4Fis+wYW1itxNAbWo+ct/cMu6TUaRHsXk9WDc3LdnWJARJdxXqScjR/6mW6kKdx/4nvOf22LdWmXkbHDxbmPTfJ/lCzJiGVPeVdqLRqivpKtYYMZglnDJXLXHyJ0H230x9MYG6XtNoow05jNWCpX33ZLi8nzX048k+8iJNhktt7eSoVk1eRRmxL9JYJlRo2BhnZ7brtC3gOBTm4xeLJjKTFNhRvzhvpd9IKVv1Rld5zOCSZ0mc6pNRmVVT2rEGXGH+173U73I3mWw7IyVl7mVqitG1eayOCPucN8rI0/wPJ06mXqp05DdoB0xqonNNWDEu7Ps297R77OAZjKNcpRd9jaTbTKaFc9WXf/fhBFnuO99D3aZWxObVtlXLnsbyHbtunwYHda1RxNG2pCrLT7Om5hLg/SKiJIzIVJ+i4xyv3e9E7QRI7697j/PbVk3OEGsLNt8TSdqsiVIpdpkNM3CwvXZ9M0YcTl1Ks4/ou6ixSRj/+YllZdInKlVRukGEMf66UIzRlzJDVVnVDmb5o88ObyXKt2L0Soj2/Lgsb0hI55Lrz6PL2jY39mfx5PIP0esXUbx4RLQUtamjDiSG2rOtVzjBq+SiW6fma3STYaWGen4Gw6mNGTEkdxQdz7s5EBExw9cOVuXbjK0zUjHS7D2pozYkxvqz1nuLYUoYRJWhlTlH2bRNiM4ZNqcEXNyA3Re+ejGS8k0yKBmdyH57trWGcG1N2YEWY0vAs+U13oB4Tiz3Eb2tS4toYXzyv88I9Z1JDCjaFwa9wnLkQWmbaEAWIE+Vu/Rpxz6/vWxaIzikhZLZEEZJqZtIPsAr/aTfvLof4PRyTLrRV9u4jINJgyMtHgp23EZn/GIXxdlmkmOENGDMTU7TuKRpkXtK23Df5IIqF3hryPU/UKTBPXxbVmvPn33Ef/GclUf/oD68maL82qDS1829/dw6LJsQdjbSm7NSOSm+T3Jyu+lN6JK2vYvk4nnOY7jJ3peiv8U4yaPJXmOH5fg8GQterIbM7kL7ktXUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlL6v9H/ABksM1MX4vgBAAAAAElFTkSuQmCC";

export default function LoginPage() {
  const { dispatch } = useApp();
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [mustChange, setMustChange] = useState(false);
  const [pendingUser, setPendingUser] = useState<Collaborator | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Erro ao fazer login'); return; }
      if (data.user.mustChangePassword) {
        setPendingUser(data.user);
        setMustChange(true);
      } else {
        dispatch({ type: 'SET_CURRENT_USER', payload: data.user });
        router.push('/dashboard');
      }
    } catch {
      setError('Erro de conexão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) { setError('A senha deve ter no mínimo 6 caracteres.'); return; }
    if (newPassword !== confirmPassword) { setError('As senhas não conferem.'); return; }
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: pendingUser?.id, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Erro ao alterar senha'); return; }
      dispatch({ type: 'SET_CURRENT_USER', payload: data.user });
      router.push('/dashboard');
    } catch {
      setError('Erro de conexão. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-dark flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background gradient orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-brand/5 rounded-full blur-[120px]" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-brand/5 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand/[0.03] rounded-full blur-[200px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-sm"
      >
        <div className="bg-bg-card border border-bg-border rounded-3xl p-8 shadow-card relative overflow-hidden">
          {/* Top accent line */}
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand/60 to-transparent" />
          
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-5 neon-glow-sm border border-brand/20">
              <img src={LOGO_BASE64} alt="Logo" className="w-10 h-10 object-contain" />
            </div>
            <h1 className="font-display text-2xl font-bold tracking-tight uppercase mb-1">Lince Performance</h1>
            <p className="text-brand text-[10px] tracking-[0.3em] uppercase font-semibold">
              {mustChange ? 'Criar Nova Senha' : 'Acesso ao Sistema'}
            </p>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-xl text-sm mb-5 flex items-center gap-2"
            >
              <AlertCircle size={15} />
              {error}
            </motion.div>
          )}

          {!mustChange ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Usuário</label>
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  className="input-base"
                  placeholder="Seu usuário"
                  required
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Senha</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="input-base pr-12"
                    placeholder="Sua senha"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20 hover:text-white/60 transition-colors"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <button type="submit" disabled={loading} className="btn-brand w-full py-4 mt-2 font-display text-sm tracking-widest uppercase">
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Entrando...
                  </span>
                ) : 'Entrar'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleChangePassword} className="space-y-4">
              <p className="text-sm text-white/40 text-center mb-2">Primeiro acesso — crie uma senha segura para continuar.</p>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nova Senha</label>
                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="input-base" placeholder="Mínimo 6 caracteres" required />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Confirmar Senha</label>
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="input-base" placeholder="Repita a senha" required />
              </div>
              <button type="submit" disabled={loading} className="btn-brand w-full py-4 mt-2 font-display text-sm tracking-widest uppercase">
                {loading ? 'Salvando...' : 'Salvar e Entrar'}
              </button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
