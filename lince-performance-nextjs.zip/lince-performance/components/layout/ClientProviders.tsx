'use client';

import { useApp } from '@/context/AppContext';
import { SocketProvider } from '@/context/SocketContext';
import { AnimatePresence } from 'motion/react';
import SuccessPopup from '@/components/ui/SuccessPopup';
import { useCallback } from 'react';

export default function ClientProviders({ children }: { children: React.ReactNode }) {
  return (
    <SocketProvider>
      <InnerProviders>{children}</InnerProviders>
    </SocketProvider>
  );
}

function InnerProviders({ children }: { children: React.ReactNode }) {
  const { state, dispatch } = useApp();

  const handleCloseSuccess = useCallback(async () => {
    if (!state.finishedTaskData) return;
    const taskId = state.finishedTaskData.task.id;
    const taskSnapshot = state.finishedTaskData.task;
    dispatch({ type: 'SET_FINISHED_TASK', payload: null });
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isArchived: true }),
      });
      dispatch({ type: 'UPDATE_TASK', payload: { ...taskSnapshot, isArchived: true } });
    } catch (e) {
      console.error(e);
    }
  }, [state.finishedTaskData, dispatch]);

  return (
    <>
      {children}
      <AnimatePresence>
        {state.finishedTaskData && (
          <SuccessPopup
            data={state.finishedTaskData}
            onClose={handleCloseSuccess}
            collaborators={state.collaborators}
          />
        )}
      </AnimatePresence>
    </>
  );
}
