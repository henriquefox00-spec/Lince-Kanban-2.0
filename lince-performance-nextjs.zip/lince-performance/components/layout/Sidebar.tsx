'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Kanban, Edit2, History, Users, ShieldCheck, Settings, LogOut } from 'lucide-react';
import type { Collaborator } from '@/lib/types';
import { motion } from 'motion/react';

const LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaMAAAB4CAMAAABoxW2eAAAAilBMVEX////uM2PtGVb73eTtI1ruL2HuKF3wUXf0iqH1na/3r736z9jtHVjuK1/3rbz+9vjyc4/5x9H4u8j96+/2prfxXYD71d3xY4P5ws7tEFPvP2v+8fT84ujydZHsAEjsAEzvR3HzgJn1lqr1mq30j6XzhJzxYYLvRW/2orPwWHzxaojsAEL4tsTuOWjwcXuTAAANDklEQVR4nO2d2ZqyvBJGIUK0FZxQNAKO2A7d3v/tbWZRoTIQ+P5+dt6jHjSBLEgqVZVE0/61rpt9rMvmQ9Ff+/3b9+o+DQYjajn+dVGv64zjivzZ8GsQrG7xZfW/p+fjeN2biN9gcw0X43otXPGCPYeu+HNfhhlL/5SZy7YxWdHqmxFcL3Rmu2h3ETwIsgxs26XKDQsRvDrOPOrXx0PpGjva3jLqRcZst1alFUEUkU38uS9cgedT+EF5lGcW9O0B/YL9xTdChl31tMSysUUuIfw+j3ZAYwpq52r9umuKZTRgNLVpzW72488xMtLtPlxfM0b+14YY9CvGyAigbtNguxceWX+IkW59gfU1YTS/EQy1Q1k2so9OXUF36k1z608x0okP1SfOaGFbrIDS68Zk2qspSv6L9LcYmXuoPlFGC2xwEUpkk1UlpR7iLoqmv8VIt67SGc10vneokE2CKiMGuggx/RtG+T+4GYG9nQijyZ2IEUrKRMPPEr+lD0j/hJF1zv7Dz8gEbDsBRmurWYui5ceM6cpxN2z6F4yMg5bNWPkZ6dZCIqMB4ai5Urb1boiPpHd2/4ARvmvaTZiRTmrNXm5GNwk2mElOr4V6jbm/q2NGUVX2Le5isl8FGMXfl8LIe8jplVDwWu5DfICrVqeMTHQ37U3UmLv8DwKMdKvukvgYeaaswd1YvhQcyDYaumRk7Xs3G3uaux1kA6sQIx3VeDa5GHm1bjl+4RdDRvostk1GdwvH3uP8RqLnf4qRr/m7aY5FjJG9rK6Pi9FD5tOOy1ck3Whok9H86xQeVhsDWYZtk8NEO1pkpDlxkOHUhJGOfhszusntkIzps2jpRkObjHI5s+uq70aWAiG/mmfFY342QRJkpFuVUQoORmfZ/REqWXd/qa97k4+sUJvY+5hK5tQSZWTfmzFaS7ePdfKMK8n2NHTI6GFELft4RD+Fu0dauigjHa2bMPLk+9R00yje7YFkT0N3jKZGhGdvR3dy/pldxOew6ReNit6OmdFKfownqqAYkoaSO7vOGM0JcrRbbDZPtzOtYV8XtUjwWQUro7X88EEsknuFZBt2XTGaWMZCW8V+nNXO1dzGjJ4tws9Il+0ISGU+svIdyc9AV4y8HcY3y4+MXtLTtHHWGzRgZJqijNjnmHFKkM0+1y0cIH+UkeYdSDzT26M4ALTMqmzASMcfyViMjNgQ2QZCZv8+nX5vLETPRYlVPDagx46WK/WpbXd23cww9n0zGpDmWDzGVxJ5T/1jY8TyGpkGWi7cwizx54HBEqy1srk1ZHzjCb+0zhhp3gWjnuZ8b297jY0YFf0/H6PKZMvXgtF++GE2zvuI/sVL+tkDcEOoNrQCqTNGUVX4stht/IGU90g3wtfSmRitqUaXsanOnxtdqG8gSl/tE3BDFj0nuqrhumOk7TG6lsbUZox08pqZw8SImv9GjrVXf6LlPmRj5C8A06hIgaCrS0YTEx8Kq64xo7dULhZGE4oXyKyw6Z9yaaMSpl4IDoHya9UlI80n6HdfVNiQ0VsqFwsj6BGPhWpSGzM5lGRWlPRkLmB829SlBVXqlJE2L+fsNmX0mtzAwojS1YFvUSwHfpNw0lFCk1hTF2m1bhlpQYlIY0YvyQ0sjODppVE/FuUagZ1lekNgh4pEFjJ1zGgi8z3Sy1mIDIygXuhpO4MKwd6SJASgWozFnFHrmZtnBXTMqOy6Z2FEscNKyQ0MjOAJLGJa6wd7ERLrG7whw2IWIlmgrGtGpWeZgRGmePpLYzADIzBnB874LzQH35KkveSlb2X9RNeMSn5nBkaWu4BnnWiel8vA6ALeK+PUpQ+5epIZ0l4aIzuNwXTOKCyYsDAawRdYCvcxMAKHI0Jd7ZrKQYZh1Cy7NZI7ukljZKZGUeeMXB4/Q8TIh+edRbiPzgiM7EDp/q/yF4vr1+l0PIZhOAgLpT/GH5AX6M363/YZrVdki6ZPR9WDw6ca+7eucG+XT2rojECzTswDUCl5Cy4zU7NtRpP+zpjPfq3tKu+UjjkURkaU/j2P29AZgZ8Q86RVSl46sZmsvG+d0WYT7qJ3gax1PYNUrEdkZUTr7VJXJp3RHPrExyoVcR3+GKNBNKY72unmV5uYecpt3tmxMtK+YAM8DffRGYHeOtRgu5A3/TFGDlnNZuPHNraQez+ZnXzOqDAzgo3mLNxHZwTOtf5/Gd0f++0WnVPf5xmlfxyy55xkjHpwb5eE+9R7JKjlS9wRpcGEPAONnRHFTZb0dg0Z/TfHo31SYJfzo2k6l+mx59cVsWXYv2Jij4ERGCiXeKsSGaWTtu4YeT184GPbzhdgBAcFdFP3wPzQhBH8CcaduRgk0fbu1M+wDkxCENluN0dHhBGYbROXZYegbzZm5MvxM2i+OxqNZpHWH0o6TPruIazKVoh0wcgLyfb+je6TiTM6PbZ9XText/u7Labw5TRVEUbaSWxlfc7oSvv6x4Z0ucaIarAY6aMIhXtxTemwYEYNgvz3Q/bDpHSQwIvXTYQRJdxX2zYZI9rilvie8fUzi2v+YBgJsz1yoGxYa/5RNINARuYtmHLqnluM4TaNFvVKqyLnL00kxIg2pFSrWGtJcc0ml2WQ+7yMyQ2ZNgDP64Ccu0JmHS3F0ObVc1es8dYMh9flzzJ5vJzL7N12FmJEC/dVq2DENqDZBnkEp+F8PR+HKwOx7aGf+ykgn5XQsgmJzqVUxnPnMufYt0l+PMOYBO8OYTFGQptgPNf+swZ3zPi4Fis+wYW1itxNAbWo+ct/cMu6TUaRHsXk9WDc3LdnWJARJdxXqScjR/6mW6kKdx/4nvOf22LdWmXkbHDxbmPTfJ/lCzJiGVPeVdqLRqivpKtYYMZglnDJXLXHyJ0H230x9MYG6XtNoow05jNWCpX33ZLi8nzX048k+8iJNhktt7eSoVk1eRRmxL9JYJlRo2BhnZ7brtC3gOBTm4xeLJjKTFNhRvzhvpd9IKVv1Rld5zOCSZ0mc6pNRmVVT2rEGXGH+173U73I3mWw7IyVl7mVqitG1eayOCPucN8rI0/wPJ06mXqp05DdoB0xqonNNWDEu7Ps297R77OAZjKNcpRd9jaTbTKaFc9WXf/fhBFnuO99D3aZWxObVtlXLnsbyHbtunwYHda1RxNG2pCrLT7Om5hLg/SKiJIzIVJ+i4xyv3e9E7QRI7697j/PbVk3OEGsLNt8TSdqsiVIpdpkNM3CwvXZ9M0YcTl1Ks4/ou6ixSRj/+YllZdInKlVRukGEMf66UIzRlzJDVVnVDmb5o88ObyXKt2L0Soj2/Lgsb0hI55Lrz6PL2jY39mfx5PIP0esXUbx4RLQUtamjDiSG2rOtVzjBq+SiW6fma3STYaWGen4Gw6mNGTEkdxQdz7s5EBExw9cOVuXbjK0zUjHS7D2pozYkxvqz1nuLYUoYRJWhlTlH2bRNiM4ZNqcEXNyA3Re+ejGS8k0yKBmdyH57trWGcG1N2YEWY0vAs+U13oB4Tiz3Eb2tS4toYXzyv88I9Z1JDCjaFwa9wnLkQWmbaEAWIE+Vu/Rpxz6/vWxaIzikhZLZEEZJqZtIPsAr/aTfvLof4PRyTLrRV9u4jINJgyMtHgp23EZn/GIXxdlmkmOENGDMTU7TuKRpkXtK23Df5IIqF3hryPU/UKTBPXxbVmvPn33Ef/GclUf/oD68maL82qDS1829/dw6LJsQdjbSm7NSOSm+T3Jyu+lN6JK2vYvk4nnOY7jJ3peiv8U4yaPJXmOH5fg8GQterIbM7kL7ktXUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlJSUlL6v9H/ABksM1MX4vgBAAAAAElFTkSuQmCC";

export default function Sidebar({ currentUser, onLogout }: {
  currentUser: Collaborator;
  onLogout: () => void;
}) {
  const pathname = usePathname();

  const menuItems = [
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/kanban', label: 'Kanban', icon: Kanban },
    { href: '/panels', label: 'Brainstorm', icon: Edit2 },
    { href: '/completed', label: 'Histórico', icon: History },
    { href: '/clients', label: 'Clientes', icon: Users },
    { href: '/collaborators', label: 'Colaboradores', icon: ShieldCheck },
    ...(currentUser.isAdmin ? [{ href: '/settings', label: 'Configurações', icon: Settings }] : []),
  ];

  return (
    <aside className="w-60 bg-bg-card border-r border-bg-border flex flex-col h-screen shrink-0">
      {/* Logo */}
      <div className="p-6 pb-4">
        <div className="flex items-center gap-2.5 bg-white/5 p-2.5 rounded-xl border border-white/5 mb-1">
          <img src={LOGO_BASE64} alt="LP" className="w-8 h-8 rounded-lg object-contain neon-glow-sm" />
          <h1 className="font-display text-lg font-bold tracking-tight uppercase">Lince</h1>
        </div>
        <p className="text-[9px] font-bold tracking-[0.3em] text-white/20 uppercase pl-14 -mt-0.5">Performance</p>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-2 space-y-0.5 overflow-y-auto">
        {menuItems.map((item) => {
          const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`sidebar-item relative ${active ? 'sidebar-item-active' : 'sidebar-item-inactive'}`}
            >
              {active && (
                <motion.div
                  layoutId="sidebar-indicator"
                  className="absolute left-0 w-0.5 h-6 bg-brand rounded-r-full"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
              <item.icon size={18} className="shrink-0" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User */}
      <div className="p-4 border-t border-bg-border">
        <div className="flex items-center gap-3 mb-3 px-2">
          <div className="w-9 h-9 rounded-full bg-brand/[0.15] border border-brand/20 flex items-center justify-center text-brand font-bold text-sm shrink-0">
            {currentUser.name.charAt(0)}
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-semibold truncate">{currentUser.name}</p>
            <p className="text-[11px] text-white/30 truncate">{currentUser.role || currentUser.sector}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 text-white/30 hover:text-white hover:bg-white/5 rounded-xl transition-all text-sm"
        >
          <LogOut size={16} />
          <span>Sair</span>
        </button>
      </div>
    </aside>
  );
}
