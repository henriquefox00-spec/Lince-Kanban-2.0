'use client';

import { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { MoreVertical, ArrowRight } from 'lucide-react';
import type { Task, Collaborator } from '@/lib/types';
import { PRIORITY_STYLES } from '@/lib/utils';

interface TaskCardProps {
  task: Task;
  clientName: string;
  collaborators: Collaborator[];
  statuses: string[];
  onClick: () => void;
  onMove: (taskId: string, status: string) => void;
}

export default function TaskCard({ task, clientName, collaborators, statuses, onClick, onMove }: TaskCardProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    if (menuOpen) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [menuOpen]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      whileHover={{ y: -2 }}
      onClick={onClick}
      className="bg-bg-card border border-bg-border hover:border-white/10 p-4 rounded-2xl cursor-pointer transition-all group relative"
    >
      <div className="flex justify-between items-start mb-3">
        <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-md ${PRIORITY_STYLES[task.priority]}`}>
          {task.priority}
        </span>
        <div className="relative" ref={menuRef}>
          <button
            onClick={e => { e.stopPropagation(); setMenuOpen(!menuOpen); }}
            className="text-white/[0.15] group-hover:text-white/40 p-1 hover:bg-white/5 rounded-lg transition-all"
          >
            <MoreVertical size={14} />
          </button>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className="absolute right-0 mt-1 w-44 bg-bg-card border border-bg-border rounded-2xl shadow-card z-20 py-2 overflow-hidden"
            >
              <p className="px-4 py-1.5 text-[9px] font-bold text-white/20 uppercase tracking-widest">Mover para</p>
              {statuses.filter(s => s !== task.status).map(status => (
                <button
                  key={status}
                  onClick={e => { e.stopPropagation(); onMove(task.id, status); setMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 text-xs hover:bg-brand/10 hover:text-brand transition-colors flex items-center gap-2"
                >
                  <ArrowRight size={11} />
                  {status}
                </button>
              ))}
            </motion.div>
          )}
        </div>
      </div>

      <h3 className="font-medium text-sm mb-1 line-clamp-2 leading-snug">{task.title}</h3>
      <p className="text-xs text-white/30 mb-4">{clientName}</p>

      <div className="flex items-center justify-between">
        <div className="flex -space-x-1.5">
          {collaborators.slice(0, 3).map(c => (
            <div
              key={c.id}
              title={c.name}
              className="w-6 h-6 rounded-full bg-brand/20 border-2 border-bg-card flex items-center justify-center text-[8px] font-bold text-brand"
            >
              {c.name.charAt(0)}
            </div>
          ))}
          {collaborators.length === 0 && (
            <div className="w-6 h-6 rounded-full bg-white/5 border-2 border-bg-card flex items-center justify-center">
              <span className="text-[8px] text-white/20">?</span>
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-1 justify-end max-w-[110px]">
          {task.sectors.slice(0, 2).map(s => (
            <span key={s} className="text-[8px] bg-white/5 px-1.5 py-0.5 rounded text-white/30 whitespace-nowrap">
              {s}
            </span>
          ))}
          {task.sectors.length > 2 && (
            <span className="text-[8px] text-white/20">+{task.sectors.length - 2}</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
