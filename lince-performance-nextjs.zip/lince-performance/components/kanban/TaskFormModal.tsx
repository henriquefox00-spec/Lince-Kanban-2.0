'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import Modal from '@/components/ui/Modal';
import type { Task } from '@/lib/types';
import { generateId } from '@/lib/utils';

interface TaskFormModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TaskFormModal({ isOpen, onClose }: TaskFormModalProps) {
  const { state, dispatch } = useApp();
  const { clients, collaborators, boards, sectors } = state;

  const [form, setForm] = useState<Partial<Task>>({
    title: '',
    clientId: '',
    sectors: [],
    collaboratorIds: [],
    status: boards[0]?.name || '',
    priority: 'Medium',
    description: '',
  });

  const toggleSector = (name: string) => {
    setForm(f => ({
      ...f,
      sectors: f.sectors?.includes(name) ? f.sectors.filter(s => s !== name) : [...(f.sectors || []), name],
    }));
  };

  const toggleCollab = (id: string) => {
    setForm(f => ({
      ...f,
      collaboratorIds: f.collaboratorIds?.includes(id) ? f.collaboratorIds.filter(c => c !== id) : [...(f.collaboratorIds || []), id],
    }));
  };

  const handleSubmit = async () => {
    if (!form.title?.trim() || !form.clientId || !form.status) {
      alert('Preencha título, cliente e quadro.');
      return;
    }
    const task: Task = {
      ...(form as Task),
      id: generateId(),
      createdAt: new Date().toISOString(),
      isArchived: false,
      title: form.title!.trim(),
    };
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
      });
      if (res.ok) {
        dispatch({ type: 'ADD_TASK', payload: task });
        setForm({ title: '', clientId: '', sectors: [], collaboratorIds: [], status: boards[0]?.name || '', priority: 'Medium', description: '' });
        onClose();
      }
    } catch (e) { console.error(e); }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Nova Demanda" size="lg">
      <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
        <div>
          <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Título *</label>
          <input
            type="text" value={form.title || ''} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            className="input-base" placeholder="Título da demanda" autoFocus
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Cliente *</label>
            <select
              value={form.clientId} onChange={e => setForm(f => ({ ...f, clientId: e.target.value }))}
              className="input-base"
            >
              <option value="">Selecionar...</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.company}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Quadro *</label>
            <select
              value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="input-base"
            >
              {boards.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Prioridade</label>
          <div className="flex gap-2">
            {(['Low', 'Medium', 'High'] as const).map(p => (
              <button
                key={p}
                onClick={() => setForm(f => ({ ...f, priority: p }))}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all border ${
                  form.priority === p
                    ? p === 'Low' ? 'bg-blue-500/20 text-blue-400 border-blue-500/40' : p === 'Medium' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40' : 'bg-red-500/20 text-red-400 border-red-500/40'
                    : 'bg-white/5 text-white/30 border-transparent hover:border-white/10'
                }`}
              >
                {p === 'Low' ? 'Baixa' : p === 'Medium' ? 'Média' : 'Alta'}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Setores</label>
          <div className="flex flex-wrap gap-2">
            {sectors.map(s => (
              <button
                key={s.id}
                onClick={() => toggleSector(s.name)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all border ${
                  form.sectors?.includes(s.name)
                    ? 'bg-brand/20 text-brand border-brand/30'
                    : 'bg-white/5 text-white/40 border-transparent hover:border-white/10'
                }`}
              >
                {s.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Responsáveis</label>
          <div className="flex flex-wrap gap-2">
            {collaborators.map(c => (
              <button
                key={c.id}
                onClick={() => toggleCollab(c.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all border ${
                  form.collaboratorIds?.includes(c.id)
                    ? 'bg-brand/20 text-brand border-brand/30'
                    : 'bg-white/5 text-white/40 border-transparent hover:border-white/10'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[9px]">{c.name.charAt(0)}</div>
                {c.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Descrição</label>
          <textarea
            value={form.description || ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            className="input-base resize-none h-24" placeholder="Detalhes da demanda..."
          />
        </div>

        <button onClick={handleSubmit} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">
          Criar Demanda
        </button>
      </div>
    </Modal>
  );
}
