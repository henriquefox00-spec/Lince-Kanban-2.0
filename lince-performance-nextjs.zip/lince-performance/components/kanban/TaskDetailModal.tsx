'use client';

import { useApp } from '@/context/AppContext';
import Modal from '@/components/ui/Modal';
import type { Task } from '@/lib/types';
import { PRIORITY_STYLES, formatDate } from '@/lib/utils';
import { ArrowRight, Calendar, Tag, Users } from 'lucide-react';

interface TaskDetailModalProps {
  task: Task;
  onClose: () => void;
  onMove: (taskId: string, status: string) => void;
}

export default function TaskDetailModal({ task, onClose, onMove }: TaskDetailModalProps) {
  const { state } = useApp();
  const { clients, collaborators, boards } = state;

  const client = clients.find(c => c.id === task.clientId);
  const taskCollabs = collaborators.filter(c => task.collaboratorIds?.includes(c.id));
  const statuses = boards.map(b => b.name);

  return (
    <Modal isOpen title={task.title} onClose={onClose} size="lg">
      <div className="space-y-5">
        <div className="flex items-center gap-3">
          <span className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-md ${PRIORITY_STYLES[task.priority]}`}>
            {task.priority}
          </span>
          <span className="text-xs bg-white/5 px-3 py-1 rounded-full text-white/50">{task.status}</span>
        </div>

        {task.description && (
          <div className="bg-white/[0.03] rounded-xl p-4 border border-white/5">
            <p className="text-sm text-white/60 leading-relaxed">{task.description}</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2 flex items-center gap-1.5">
              <Users size={11} /> Cliente
            </p>
            <p className="text-sm font-medium">{client?.company || '—'}</p>
            <p className="text-xs text-white/40">{client?.name}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2 flex items-center gap-1.5">
              <Calendar size={11} /> Criado
            </p>
            <p className="text-sm font-medium">{formatDate(task.createdAt)}</p>
          </div>
          <div>
            <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2 flex items-center gap-1.5">
              <Tag size={11} /> Setores
            </p>
            <div className="flex flex-wrap gap-1">
              {task.sectors.map(s => (
                <span key={s} className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-white/50">{s}</span>
              ))}
            </div>
          </div>
          <div>
            <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2 flex items-center gap-1.5">
              <Users size={11} /> Responsáveis
            </p>
            <div className="flex flex-wrap gap-1.5">
              {taskCollabs.map(c => (
                <div key={c.id} className="flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded-lg">
                  <div className="w-4 h-4 rounded-full bg-brand/20 flex items-center justify-center text-[8px] font-bold text-brand">{c.name.charAt(0)}</div>
                  <span className="text-[10px] text-white/60">{c.name}</span>
                </div>
              ))}
              {taskCollabs.length === 0 && <span className="text-xs text-white/20">Nenhum</span>}
            </div>
          </div>
        </div>

        <div>
          <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Mover para</p>
          <div className="flex flex-wrap gap-2">
            {statuses.filter(s => s !== task.status).map(s => (
              <button
                key={s}
                onClick={() => { onMove(task.id, s); onClose(); }}
                className="flex items-center gap-1.5 bg-white/5 hover:bg-brand/[0.15] hover:text-brand text-white/50 px-3 py-2 rounded-xl text-xs font-medium transition-all border border-transparent hover:border-brand/20"
              >
                <ArrowRight size={12} />
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}
