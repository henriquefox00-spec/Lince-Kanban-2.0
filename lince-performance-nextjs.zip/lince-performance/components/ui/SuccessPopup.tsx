'use client';

import { motion } from 'motion/react';
import { CheckCircle2, X } from 'lucide-react';
import type { Collaborator, Task } from '@/lib/types';
import { formatDuration } from '@/lib/utils';

interface SuccessPopupProps {
  data: { task: Task & { clientName?: string }; history: Array<{ collaboratorId: string; timestamp: string }> };
  onClose: () => void;
  collaborators: Collaborator[];
}

export default function SuccessPopup({ data, onClose, collaborators }: SuccessPopupProps) {
  const { task, history } = data;
  const getCollaboratorName = (id: string) => collaborators.find(c => c.id === id)?.name || 'Desconhecido';

  const startTime = new Date(task.createdAt).getTime();
  const endTime = Date.now();
  const totalDuration = endTime - startTime;

  const timePerCollab: Record<string, number> = {};
  for (let i = 0; i < history.length; i++) {
    const current = history[i];
    const next = history[i + 1];
    const start = new Date(current.timestamp).getTime();
    const end = next ? new Date(next.timestamp).getTime() : endTime;
    timePerCollab[current.collaboratorId] = (timePerCollab[current.collaboratorId] || 0) + (end - start);
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="bg-bg-card border border-brand/20 p-8 rounded-[2rem] w-full max-w-md shadow-brand relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand to-transparent" />
        
        <button onClick={onClose} className="absolute top-5 right-5 text-white/20 hover:text-white/60 transition-colors">
          <X size={18} />
        </button>

        <div className="flex flex-col items-center text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 300 }}
            className="w-20 h-20 bg-brand/10 rounded-full flex items-center justify-center mb-4 neon-glow"
          >
            <CheckCircle2 size={40} className="text-brand" />
          </motion.div>
          <h2 className="font-display text-3xl font-bold uppercase mb-1">Sucesso!</h2>
          <p className="text-brand font-bold tracking-[0.2em] uppercase text-xs">Task Finalizada</p>
        </div>

        <div className="space-y-4">
          <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
            <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-1">Tarefa</p>
            <h3 className="font-display text-lg font-bold">{task.title}</h3>
            {task.clientName && <p className="text-sm text-white/40 mt-0.5">{task.clientName}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
              <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-1">Tempo Total</p>
              <p className="font-display text-lg font-bold text-brand">{formatDuration(totalDuration)}</p>
            </div>
            <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
              <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-1">Setor(es)</p>
              <p className="font-display text-sm font-bold truncate">{task.sectors?.join(', ') || 'N/A'}</p>
            </div>
          </div>

          {Object.keys(timePerCollab).length > 0 && (
            <div>
              <p className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-3">Tempo por Colaborador</p>
              <div className="space-y-2">
                {Object.entries(timePerCollab).map(([id, duration]) => (
                  <div key={id} className="flex justify-between items-center bg-white/5 px-4 py-2.5 rounded-xl">
                    <span className="text-sm font-medium">{getCollaboratorName(id)}</span>
                    <span className="text-sm font-mono text-white/40">{formatDuration(duration)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="btn-brand w-full py-4 mt-6 font-display uppercase tracking-widest text-sm"
        >
          Fechar
        </button>
      </motion.div>
    </motion.div>
  );
}
