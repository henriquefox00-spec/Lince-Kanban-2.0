export function formatDuration(ms: number): string {
  if (isNaN(ms) || ms < 0) return 'N/A';
  const hours = Math.floor(ms / (1000 * 60 * 60));
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
}

export function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export const PRIORITY_STYLES = {
  Low: 'bg-blue-500/20 text-blue-400 border border-blue-500/20',
  Medium: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/20',
  High: 'bg-red-500/20 text-red-400 border border-red-500/20',
} as const;
