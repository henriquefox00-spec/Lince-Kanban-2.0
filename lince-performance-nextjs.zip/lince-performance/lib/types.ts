export type Sector = string;

export interface SectorEntity {
  id: string;
  name: string;
  createdAt: string;
}

export type TaskStatus = string;

export interface Board {
  id: string;
  name: string;
  position: number;
  createdAt: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  company: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface Collaborator {
  id: string;
  name: string;
  email: string;
  sector: Sector;
  role: string;
  isAdmin: boolean;
  avatar?: string;
  username?: string;
  mustChangePassword?: boolean;
  createdAt: string;
}

export interface TaskHistory {
  taskId: string;
  collaboratorId: string;
  status: TaskStatus;
  timestamp: string;
}

export interface Task {
  id: string;
  title: string;
  clientId: string;
  sectors: Sector[];
  collaboratorIds: string[];
  status: TaskStatus;
  priority: 'Low' | 'Medium' | 'High';
  description?: string;
  completedAt?: string;
  isArchived?: boolean;
  createdAt: string;
}

export interface Panel {
  id: string;
  name: string;
  collaboratorId: string;
  createdAt: string;
}

export interface PanelItem {
  id: string;
  panelId: string;
  type: 'note' | 'checklist' | 'standard';
  title: string;
  content: string;
  checklist: string;
  collaboratorIds: string[];
  position: number;
  isArchived: boolean;
  isCompleted: boolean;
  createdAt: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
  completedAt?: string;
}
