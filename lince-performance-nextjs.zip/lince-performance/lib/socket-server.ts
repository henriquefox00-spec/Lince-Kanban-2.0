import { Server } from 'socket.io';

let io: Server | null = null;

export function setIO(server: Server) {
  io = server;
}

export function getIO(): Server | null {
  return io;
}

export function emit(event: string, data?: unknown) {
  if (io) {
    io.emit(event, data);
  }
}
