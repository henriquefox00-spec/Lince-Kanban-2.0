'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, Trash2, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';
import ConfirmModal from '@/components/ui/ConfirmModal';
import { generateId } from '@/lib/utils';
import type { SectorEntity } from '@/lib/types';

export default function SettingsPage() {
  const { state, dispatch } = useApp();
  const { sectors, currentUser } = state;
  const [newSectorName, setNewSectorName] = useState('');
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
  const [resetConfirm, setResetConfirm] = useState(false);

  if (!currentUser?.isAdmin) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <AlertTriangle size={40} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40">Acesso restrito a administradores</p>
        </div>
      </div>
    );
  }

  const handleAddSector = async () => {
    if (!newSectorName.trim()) return;
    const sector: SectorEntity = { id: generateId(), name: newSectorName.trim(), createdAt: new Date().toISOString() };
    try {
      const res = await fetch('/api/sectors', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(sector) });
      if (res.ok) { dispatch({ type: 'ADD_SECTOR', payload: sector }); setNewSectorName(''); }
    } catch (e) { console.error(e); }
  };

  const handleDeleteSector = (id: string) => {
    setConfirm({
      title: 'Excluir Setor',
      message: 'Tem certeza? Isso pode afetar as tarefas associadas.',
      onConfirm: async () => {
        await fetch(`/api/sectors/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_SECTOR', payload: id });
      },
    });
  };

  const handleReset = async () => {
    try {
      await fetch('/api/reset', { method: 'POST' });
      dispatch({ type: 'SET_ALL_DATA', payload: { tasks: [], clients: [], panels: [], panelItems: [] } });
    } catch (e) { console.error(e); }
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Configurações</h2>
        <p className="text-white/30 text-sm">Gerencie setores e dados do sistema.</p>
      </div>

      {/* Sectors */}
      <div className="card p-6 space-y-5">
        <h3 className="font-display font-bold text-lg">Setores</h3>
        <div className="flex gap-3">
          <input
            type="text" value={newSectorName} onChange={e => setNewSectorName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleAddSector()}
            className="input-base flex-1" placeholder="Nome do setor..."
          />
          <button onClick={handleAddSector} className="btn-brand px-5 flex items-center gap-2 text-sm">
            <Plus size={16} /> Adicionar
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {sectors.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.03 }}
              className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-xl"
            >
              <span className="text-sm font-medium">{s.name}</span>
              <button onClick={() => handleDeleteSector(s.id)} className="text-white/20 hover:text-red-400 transition-colors ml-1">
                <Trash2 size={13} />
              </button>
            </motion.div>
          ))}
          {sectors.length === 0 && <p className="text-white/20 text-sm">Nenhum setor cadastrado</p>}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="card p-6 border-red-500/10 space-y-4">
        <h3 className="font-display font-bold text-lg text-red-400 flex items-center gap-2">
          <AlertTriangle size={18} /> Zona de Risco
        </h3>
        <p className="text-sm text-white/40">Estas ações são irreversíveis. Tenha cuidado.</p>
        <button
          onClick={() => setResetConfirm(true)}
          className="bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold px-6 py-3 rounded-xl transition-all text-sm border border-red-500/20"
        >
          Resetar Todos os Dados
        </button>
      </div>

      {confirm && <ConfirmModal isOpen onClose={() => setConfirm(null)} onConfirm={confirm.onConfirm} title={confirm.title} message={confirm.message} />}
      <ConfirmModal
        isOpen={resetConfirm}
        onClose={() => setResetConfirm(false)}
        onConfirm={handleReset}
        title="Resetar Sistema"
        message="Isso apagará TODAS as tasks, clientes e painéis. Esta ação é irreversível."
      />
    </div>
  );
}
