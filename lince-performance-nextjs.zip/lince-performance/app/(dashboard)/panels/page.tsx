'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import Modal from '@/components/ui/Modal';
import ConfirmModal from '@/components/ui/ConfirmModal';
import { useRouter } from 'next/navigation';
import type { Panel } from '@/lib/types';
import { generateId, formatDate } from '@/lib/utils';

export default function PanelsPage() {
  const { state, dispatch } = useApp();
  const { panels, currentUser } = state;
  const router = useRouter();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newPanelName, setNewPanelName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);

  // Filter panels to current user
  const userPanels = panels.filter(p => p.collaboratorId === currentUser?.id);

  const handleCreate = async () => {
    if (!newPanelName.trim() || !currentUser) return;
    const panel: Panel = { id: generateId(), name: newPanelName.trim(), collaboratorId: currentUser.id, createdAt: new Date().toISOString() };
    try {
      const res = await fetch('/api/panels', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(panel) });
      if (res.ok) {
        dispatch({ type: 'ADD_PANEL', payload: panel });
        setIsModalOpen(false);
        setNewPanelName('');
        router.push(`/panels/${panel.id}`);
      }
    } catch (e) { console.error(e); }
  };

  const handleRename = async (id: string, name: string) => {
    try {
      await fetch(`/api/panels/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
      dispatch({ type: 'UPDATE_PANEL', payload: { ...panels.find(p => p.id === id)!, name } });
      setEditingId(null);
    } catch (e) { console.error(e); }
  };

  const handleDelete = (id: string) => {
    setConfirm({
      title: 'Excluir Painel',
      message: 'Todos os cards deste painel serão apagados.',
      onConfirm: async () => {
        await fetch(`/api/panels/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_PANEL', payload: id });
      },
    });
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Brainstorm</h2>
          <p className="text-white/30 text-sm">Organize suas ideias, notas e checklists.</p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="btn-brand flex items-center gap-2 text-sm">
          <Plus size={16} /> Novo Painel
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {userPanels.map((panel, i) => (
          <motion.div
            key={panel.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            whileHover={{ y: -3 }}
            className="card p-6 hover:border-white/10 transition-all cursor-pointer group relative"
            onClick={() => router.push(`/panels/${panel.id}`)}
          >
            <div className="flex justify-between items-start mb-5">
              <div className="w-12 h-12 rounded-2xl bg-brand/10 border border-brand/10 flex items-center justify-center text-brand group-hover:bg-brand group-hover:text-white transition-all">
                <Edit2 size={22} />
              </div>
              <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={e => { e.stopPropagation(); setEditingId(panel.id); setEditName(panel.name); }}
                  className="p-2 text-white/20 hover:text-brand rounded-xl transition-all"
                >
                  <Edit2 size={14} />
                </button>
                <button
                  onClick={e => { e.stopPropagation(); handleDelete(panel.id); }}
                  className="p-2 text-white/20 hover:text-red-400 rounded-xl transition-all"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
            {editingId === panel.id ? (
              <form onClick={e => e.stopPropagation()} onSubmit={e => { e.preventDefault(); handleRename(panel.id, editName); }} className="mb-2">
                <input
                  autoFocus value={editName} onChange={e => setEditName(e.target.value)}
                  onBlur={() => setEditingId(null)}
                  className="w-full bg-white/5 border border-brand/30 rounded-xl px-3 py-1.5 text-sm focus:outline-none"
                />
              </form>
            ) : (
              <h3 className="font-display font-bold text-lg mb-1">{panel.name}</h3>
            )}
            <p className="text-xs text-white/30">Criado em {formatDate(panel.createdAt)}</p>
          </motion.div>
        ))}

        {userPanels.length === 0 && (
          <div className="col-span-full py-24 text-center border border-dashed border-white/10 rounded-3xl">
            <Edit2 size={32} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/20 text-sm">Nenhum painel criado ainda. Comece agora!</p>
          </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Painel">
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nome do Painel</label>
            <input
              type="text" value={newPanelName} onChange={e => setNewPanelName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleCreate()}
              className="input-base" placeholder="Ex: Ideias de Campanha" autoFocus
            />
          </div>
          <button onClick={handleCreate} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Criar Painel</button>
        </div>
      </Modal>

      {confirm && <ConfirmModal isOpen onClose={() => setConfirm(null)} onConfirm={confirm.onConfirm} title={confirm.title} message={confirm.message} />}
    </div>
  );
}
