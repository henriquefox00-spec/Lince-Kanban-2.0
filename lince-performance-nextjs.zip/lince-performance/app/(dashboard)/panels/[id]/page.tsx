'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { ArrowLeft, Plus, FileText, CheckSquare, Archive, Trash2, GripVertical, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import Modal from '@/components/ui/Modal';
import ConfirmModal from '@/components/ui/ConfirmModal';
import type { PanelItem, ChecklistItem } from '@/lib/types';
import { generateId } from '@/lib/utils';

// Checklist Card sub-component
function PanelCard({ item, onUpdate, onDelete, onArchive, onComplete }: {
  item: PanelItem;
  onUpdate: (updates: Partial<PanelItem>) => Promise<void>;
  onDelete: () => Promise<void>;
  onArchive: () => Promise<void>;
  onComplete?: (item: PanelItem) => void;
}) {
  const [content, setContent] = useState(item.content);
  const [isEditing, setIsEditing] = useState(false);
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [newItem, setNewItem] = useState('');

  useEffect(() => {
    setContent(item.content);
    try { setChecklist(JSON.parse(item.checklist || '[]')); } catch { setChecklist([]); }
  }, [item.content, item.checklist]);

  const saveNote = () => { onUpdate({ content }); setIsEditing(false); };

  const toggleCheck = (id: string) => {
    const updated = checklist.map(i => i.id === id ? { ...i, completed: !i.completed, completedAt: !i.completed ? new Date().toISOString() : undefined } : i);
    setChecklist(updated);
    onUpdate({ checklist: JSON.stringify(updated) });
    if (updated.length > 0 && updated.every(i => i.completed) && onComplete) onComplete({ ...item, checklist: JSON.stringify(updated) });
  };

  const addCheckItem = () => {
    if (!newItem.trim()) return;
    const updated = [...checklist, { id: generateId(), text: newItem.trim(), completed: false, createdAt: new Date().toISOString() }];
    setChecklist(updated);
    onUpdate({ checklist: JSON.stringify(updated) });
    setNewItem('');
  };

  const removeCheckItem = (id: string) => {
    const updated = checklist.filter(i => i.id !== id);
    setChecklist(updated);
    onUpdate({ checklist: JSON.stringify(updated) });
  };

  const doneCount = checklist.filter(i => i.completed).length;
  const progress = checklist.length > 0 ? Math.round((doneCount / checklist.length) * 100) : 0;

  return (
    <Reorder.Item value={item} className="bg-bg-card border border-bg-border rounded-2xl overflow-hidden group w-72 shrink-0 h-fit hover:border-white/10 transition-all">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-2.5">
            <div className="cursor-grab active:cursor-grabbing text-white/[0.15] hover:text-white/40 transition-colors">
              <GripVertical size={16} />
            </div>
            <div className="w-8 h-8 rounded-xl flex items-center justify-center bg-brand/10 text-brand">
              {item.checklist && JSON.parse(item.checklist || '[]').length > 0 ? <CheckSquare size={15} /> : <FileText size={15} />}
            </div>
            <h4 className="font-display font-bold text-sm">{item.title}</h4>
          </div>
          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={onArchive} className="p-1.5 text-white/20 hover:text-brand rounded-lg transition-colors" title="Arquivar">
              <Archive size={14} />
            </button>
            <button onClick={onDelete} className="p-1.5 text-white/20 hover:text-red-400 rounded-lg transition-colors" title="Excluir">
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        {/* Content note */}
        {item.type !== 'checklist' && (
          <div className="mb-4">
            {isEditing ? (
              <div>
                <textarea value={content} onChange={e => setContent(e.target.value)} className="w-full bg-white/5 border border-brand/30 rounded-xl p-3 text-sm focus:outline-none resize-none h-24" autoFocus />
                <div className="flex gap-2 mt-2">
                  <button onClick={saveNote} className="text-xs bg-brand/20 text-brand px-3 py-1.5 rounded-lg hover:bg-brand/30 transition-all">Salvar</button>
                  <button onClick={() => { setContent(item.content); setIsEditing(false); }} className="text-xs bg-white/5 text-white/40 px-3 py-1.5 rounded-lg hover:bg-white/10 transition-all">Cancelar</button>
                </div>
              </div>
            ) : (
              <p onClick={() => setIsEditing(true)} className="text-sm text-white/50 hover:text-white/70 transition-colors cursor-text min-h-[2rem] leading-relaxed">
                {content || <span className="text-white/20 italic">Clique para adicionar uma nota...</span>}
              </p>
            )}
          </div>
        )}

        {/* Checklist */}
        {checklist.length > 0 && (
          <div className="space-y-2 mb-3">
            {checklist.length > 1 && (
              <div className="flex items-center gap-2 mb-3">
                <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-brand rounded-full transition-all" style={{ width: `${progress}%` }} />
                </div>
                <span className="text-[10px] text-white/30">{doneCount}/{checklist.length}</span>
              </div>
            )}
            {checklist.map(ci => (
              <div key={ci.id} className="flex items-center gap-2.5 group/item">
                <button onClick={() => toggleCheck(ci.id)} className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 transition-all ${ci.completed ? 'bg-brand border-brand' : 'border-white/20 hover:border-brand'}`}>
                  {ci.completed && <CheckCircle2 size={10} className="text-white" />}
                </button>
                <span className={`text-sm flex-1 ${ci.completed ? 'line-through text-white/25' : 'text-white/70'}`}>{ci.text}</span>
                <button onClick={() => removeCheckItem(ci.id)} className="opacity-0 group-hover/item:opacity-100 text-white/[0.15] hover:text-red-400 transition-all">
                  <Trash2 size={11} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add checklist item */}
        <div className="flex gap-2">
          <input
            value={newItem} onChange={e => setNewItem(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addCheckItem()}
            placeholder="+ Adicionar item..."
            className="flex-1 bg-transparent text-xs text-white/40 placeholder:text-white/20 focus:outline-none focus:text-white/70 transition-colors"
          />
          {newItem && (
            <button onClick={addCheckItem} className="text-brand text-xs font-bold">OK</button>
          )}
        </div>
      </div>
      {item.isCompleted && (
        <div className="bg-emerald-500/10 border-t border-emerald-500/20 px-5 py-2 flex items-center gap-2">
          <CheckCircle2 size={12} className="text-emerald-400" />
          <span className="text-emerald-400 text-xs font-medium">Concluído</span>
        </div>
      )}
    </Reorder.Item>
  );
}

export default function PanelDetailPage() {
  const params = useParams();
  const router = useRouter();
  const panelId = params.id as string;
  const { state, dispatch } = useApp();
  const { panels, panelItems } = state;

  const panel = panels.find(p => p.id === panelId);
  const items = panelItems.filter(i => i.panelId === panelId);
  const activeItems = items.filter(i => !i.isArchived && !i.isCompleted);
  const completedItems = items.filter(i => !i.isArchived && i.isCompleted);
  const archivedItems = items.filter(i => i.isArchived);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState('');
  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);

  // Fetch items for this panel
  useEffect(() => {
    const fetchItems = async () => {
      const res = await fetch(`/api/panels/${panelId}/items`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          data.forEach(item => dispatch({ type: 'ADD_PANEL_ITEM', payload: item }));
        }
      }
    };
    if (panelId) fetchItems();
  }, [panelId, dispatch]);

  if (!panel) {
    return <div className="p-8 text-white/40">Painel não encontrado.</div>;
  }

  const handleAddItem = async () => {
    if (!newItemTitle.trim()) return;
    const item: PanelItem = {
      id: generateId(), panelId, type: 'standard',
      title: newItemTitle.trim(), content: '',
      checklist: '[]', collaboratorIds: [],
      position: activeItems.length,
      isArchived: false, isCompleted: false,
      createdAt: new Date().toISOString(),
    };
    try {
      const res = await fetch(`/api/panels/${panelId}/items`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(item),
      });
      if (res.ok) {
        dispatch({ type: 'ADD_PANEL_ITEM', payload: item });
        setNewItemTitle('');
        setIsModalOpen(false);
      }
    } catch (e) { console.error(e); }
  };

  const handleUpdateItem = async (id: string, updates: Partial<PanelItem>) => {
    const item = items.find(i => i.id === id);
    if (!item) return;
    dispatch({ type: 'UPDATE_PANEL_ITEM', payload: { ...item, ...updates } });
    try {
      await fetch(`/api/panel_items/${id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updates),
      });
    } catch (e) { console.error(e); }
  };

  const handleDeleteItem = async (id: string) => {
    setConfirm({
      title: 'Excluir Card',
      message: 'Este card será excluído permanentemente.',
      onConfirm: async () => {
        await fetch(`/api/panel_items/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_PANEL_ITEM', payload: id });
      },
    });
  };

  const handleReorder = async (newOrder: PanelItem[]) => {
    newOrder.forEach((item, index) => dispatch({ type: 'UPDATE_PANEL_ITEM', payload: { ...item, position: index } }));
    await Promise.all(newOrder.map((item, index) =>
      fetch(`/api/panel_items/${item.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ position: index }),
      })
    ));
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="px-8 py-6 border-b border-bg-border flex items-center gap-4 shrink-0">
        <button onClick={() => router.push('/panels')} className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/40 hover:text-white transition-all">
          <ArrowLeft size={18} />
        </button>
        <div className="flex-1">
          <h2 className="font-display text-xl font-bold">{panel.name}</h2>
          <p className="text-white/30 text-xs">{activeItems.length} card{activeItems.length !== 1 ? 's' : ''} ativo{activeItems.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white/5 p-1 rounded-xl flex gap-1">
            {(['active', 'completed'] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === tab ? 'bg-brand text-white' : 'text-white/40 hover:text-white'}`}
              >
                {tab === 'active' ? `Ativos (${activeItems.length})` : `Concluídos (${completedItems.length})`}
              </button>
            ))}
          </div>
          <button onClick={() => setIsModalOpen(true)} className="btn-brand flex items-center gap-2 text-sm">
            <Plus size={16} /> Novo Card
          </button>
        </div>
      </div>

      {/* Items */}
      <div className="flex-1 overflow-x-auto p-6">
        {activeTab === 'active' ? (
          <Reorder.Group axis="x" values={activeItems} onReorder={handleReorder} className="flex gap-5 items-start h-full">
            {activeItems.map(item => (
              <PanelCard key={item.id} item={item}
                onUpdate={updates => handleUpdateItem(item.id, updates)}
                onDelete={() => handleDeleteItem(item.id)}
                onArchive={() => handleUpdateItem(item.id, { isArchived: true })}
                onComplete={i => handleUpdateItem(i.id, { isCompleted: true })}
              />
            ))}
            {activeItems.length === 0 && (
              <div className="w-full py-24 text-center border border-dashed border-white/10 rounded-3xl">
                <p className="text-white/20 text-sm">Nenhum card ativo. Crie um novo!</p>
              </div>
            )}
          </Reorder.Group>
        ) : (
          <div className="flex gap-5 items-start">
            {completedItems.map(item => (
              <PanelCard key={item.id} item={item}
                onUpdate={updates => handleUpdateItem(item.id, updates)}
                onDelete={() => handleDeleteItem(item.id)}
                onArchive={() => handleUpdateItem(item.id, { isArchived: true })}
              />
            ))}
            {completedItems.length === 0 && (
              <div className="w-full py-24 text-center border border-dashed border-white/10 rounded-3xl">
                <p className="text-white/20 text-sm">Nenhum card concluído ainda.</p>
              </div>
            )}
          </div>
        )}

        {archivedItems.length > 0 && (
          <div className="mt-12 space-y-3">
            <p className="text-xs font-bold text-white/20 uppercase tracking-widest">Arquivados ({archivedItems.length})</p>
            <div className="flex gap-5 opacity-40">
              {archivedItems.map(item => (
                <PanelCard key={item.id} item={item}
                  onUpdate={updates => handleUpdateItem(item.id, updates)}
                  onDelete={() => handleDeleteItem(item.id)}
                  onArchive={() => handleUpdateItem(item.id, { isArchived: false })}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Card">
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Título do Card</label>
            <input
              type="text" value={newItemTitle} onChange={e => setNewItemTitle(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddItem()}
              className="input-base" placeholder="Ex: Ideias para campanha..." autoFocus
            />
          </div>
          <button onClick={handleAddItem} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Criar Card</button>
        </div>
      </Modal>

      {confirm && <ConfirmModal isOpen onClose={() => setConfirm(null)} onConfirm={confirm.onConfirm} title={confirm.title} message={confirm.message} />}
    </div>
  );
}
