'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, Trash2, Edit2, ShieldCheck, Shield } from 'lucide-react';
import { motion } from 'motion/react';
import Modal from '@/components/ui/Modal';
import ConfirmModal from '@/components/ui/ConfirmModal';
import type { Collaborator } from '@/lib/types';
import { generateId } from '@/lib/utils';

export default function CollaboratorsPage() {
  const { state, dispatch } = useApp();
  const { collaborators, sectors, currentUser } = state;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCollab, setEditingCollab] = useState<Collaborator | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
  const [form, setForm] = useState<Partial<Collaborator> & { password?: string }>({
    name: '', email: '', sector: sectors[0]?.name || 'Design', role: '', isAdmin: false, username: '', password: '',
  });

  const handleAdd = async () => {
    if (!form.name?.trim() || !form.username?.trim() || !form.password?.trim()) {
      alert('Nome, usuário e senha são obrigatórios.');
      return;
    }
    const collab: Collaborator & { password?: string } = {
      ...form as Collaborator,
      id: generateId(),
      createdAt: new Date().toISOString(),
      isAdmin: !!form.isAdmin,
      mustChangePassword: true,
    };
    try {
      const res = await fetch('/api/collaborators', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(collab) });
      if (res.ok) {
        const { password, ...safeCollab } = collab;
        dispatch({ type: 'ADD_COLLABORATOR', payload: safeCollab });
        setIsModalOpen(false);
        setForm({ name: '', email: '', sector: sectors[0]?.name || 'Design', role: '', isAdmin: false, username: '', password: '' });
      } else {
        const err = await res.json().catch(() => ({}));
        alert(`Erro: ${err.error || 'Erro no servidor'}`);
      }
    } catch (e) { console.error(e); }
  };

  const handleUpdate = async () => {
    if (!editingCollab) return;
    try {
      const payload = { ...editingCollab };
      await fetch(`/api/collaborators/${editingCollab.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      dispatch({ type: 'UPDATE_COLLABORATOR', payload: editingCollab });
      setEditingCollab(null);
    } catch (e) { console.error(e); }
  };

  const handleDelete = (id: string) => {
    if (id === 'admin-master' || id === currentUser?.id) { alert('Não é possível excluir este colaborador.'); return; }
    setConfirm({
      title: 'Excluir Colaborador',
      message: 'Tem certeza? As tarefas associadas serão apagadas.',
      onConfirm: async () => {
        await fetch(`/api/collaborators/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_COLLABORATOR', payload: id });
      },
    });
  };

  const sectorOptions = sectors.map(s => s.name);

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Colaboradores</h2>
          <p className="text-white/30 text-sm">{collaborators.length} membro{collaborators.length !== 1 ? 's' : ''} no time</p>
        </div>
        {currentUser?.isAdmin && (
          <button onClick={() => setIsModalOpen(true)} className="btn-brand flex items-center gap-2 text-sm">
            <Plus size={16} /> Novo Colaborador
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {collaborators.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="card p-5 hover:border-white/10 transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-brand/10 border border-brand/[0.15] flex items-center justify-center font-display text-lg font-bold text-brand">
                  {c.name.charAt(0)}
                </div>
                <div>
                  <p className="font-bold">{c.name}</p>
                  <p className="text-xs text-white/40">{c.role || c.sector}</p>
                </div>
              </div>
              {c.isAdmin ? <ShieldCheck size={16} className="text-brand" /> : <Shield size={16} className="text-white/10" />}
            </div>
            <div className="flex items-center justify-between">
              <div className="flex gap-1.5">
                <span className="text-[10px] bg-white/5 px-2 py-1 rounded-lg text-white/40">{c.sector}</span>
                {c.isAdmin && <span className="text-[10px] bg-brand/10 text-brand px-2 py-1 rounded-lg">Admin</span>}
              </div>
              {currentUser?.isAdmin && (
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => setEditingCollab(c)} className="p-2 text-white/20 hover:text-brand transition-colors">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => handleDelete(c.id)} className="p-2 text-white/20 hover:text-red-400 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Colaborador" size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nome *</label>
              <input type="text" value={form.name || ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="input-base" placeholder="Nome completo" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Cargo</label>
              <input type="text" value={form.role || ''} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} className="input-base" placeholder="Ex: Designer" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Usuário *</label>
              <input type="text" value={form.username || ''} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} className="input-base" placeholder="login" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Senha Inicial *</label>
              <input type="password" value={form.password || ''} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="input-base" placeholder="••••••" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">E-mail</label>
              <input type="email" value={form.email || ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="input-base" placeholder="email@lince.com" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Setor</label>
              <select value={form.sector || ''} onChange={e => setForm(f => ({ ...f, sector: e.target.value }))} className="input-base">
                {sectorOptions.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" checked={!!form.isAdmin} onChange={e => setForm(f => ({ ...f, isAdmin: e.target.checked }))} className="w-4 h-4 rounded bg-white/10 border-white/20 text-brand" />
            <span className="text-sm font-medium">Administrador</span>
          </label>
          <button onClick={handleAdd} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Criar Colaborador</button>
        </div>
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={!!editingCollab} onClose={() => setEditingCollab(null)} title="Editar Colaborador" size="lg">
        {editingCollab && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nome</label>
                <input type="text" value={editingCollab.name} onChange={e => setEditingCollab(c => c ? { ...c, name: e.target.value } : c)} className="input-base" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Cargo</label>
                <input type="text" value={editingCollab.role || ''} onChange={e => setEditingCollab(c => c ? { ...c, role: e.target.value } : c)} className="input-base" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">E-mail</label>
                <input type="email" value={editingCollab.email || ''} onChange={e => setEditingCollab(c => c ? { ...c, email: e.target.value } : c)} className="input-base" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Setor</label>
                <select value={editingCollab.sector} onChange={e => setEditingCollab(c => c ? { ...c, sector: e.target.value } : c)} className="input-base">
                  {sectorOptions.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" checked={!!editingCollab.isAdmin} onChange={e => setEditingCollab(c => c ? { ...c, isAdmin: e.target.checked } : c)} className="w-4 h-4 rounded text-brand" />
              <span className="text-sm font-medium">Administrador</span>
            </label>
            <button onClick={handleUpdate} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Salvar Alterações</button>
          </div>
        )}
      </Modal>

      {confirm && <ConfirmModal isOpen onClose={() => setConfirm(null)} onConfirm={confirm.onConfirm} title={confirm.title} message={confirm.message} />}
    </div>
  );
}
