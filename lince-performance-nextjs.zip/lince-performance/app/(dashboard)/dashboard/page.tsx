'use client';

import { useApp } from '@/context/AppContext';
import { Users, Clock, CheckCircle2, TrendingUp, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { formatDate } from '@/lib/utils';

export default function DashboardPage() {
  const { state } = useApp();
  const { tasks, clients, collaborators, boards, sectors } = state;

  const lastBoardName = boards.length > 0 ? boards[boards.length - 1].name : 'Done';
  const activeClients = clients.filter(c => c.status === 'Active').length;
  const openTasks = tasks.filter(t => !t.isArchived && t.status !== lastBoardName).length;
  const completedTasks = tasks.filter(t => t.isArchived || t.status === lastBoardName).length;
  const highPriority = tasks.filter(t => !t.isArchived && t.priority === 'High' && t.status !== lastBoardName).length;

  const tasksBySector = sectors.map(s => ({
    name: s.name,
    count: tasks.filter(t => !t.isArchived && t.sectors.includes(s.name) && t.status !== lastBoardName).length,
  })).filter(s => s.count > 0).sort((a, b) => b.count - a.count);

  const recentTasks = [...tasks]
    .filter(t => !t.isArchived)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const stats = [
    { label: 'Clientes Ativos', value: activeClients, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/10' },
    { label: 'Demandas Abertas', value: openTasks, icon: Clock, color: 'text-brand', bg: 'bg-brand/10', border: 'border-brand/10' },
    { label: 'Finalizadas', value: completedTasks, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/10' },
    { label: 'Alta Prioridade', value: highPriority, icon: AlertCircle, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/10' },
  ];

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <header>
        <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Visão Geral</h2>
        <p className="text-white/40 text-sm">Bem-vindo de volta. Aqui está o que está acontecendo hoje.</p>
      </header>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className={`stat-card border ${stat.border}`}
          >
            <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center mb-4`}>
              <stat.icon size={20} className={stat.color} />
            </div>
            <p className="text-3xl font-display font-bold mb-1">{stat.value}</p>
            <p className="text-xs text-white/40 font-medium">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Recent Tasks */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.4 }}
          className="lg:col-span-3 card p-6"
        >
          <h3 className="font-display font-bold text-lg mb-5 flex items-center gap-2">
            <Clock size={18} className="text-brand" />
            Demandas Recentes
          </h3>
          <div className="space-y-3">
            {recentTasks.length === 0 ? (
              <p className="text-white/20 text-sm text-center py-8">Nenhuma demanda ativa</p>
            ) : recentTasks.map(task => {
              const client = clients.find(c => c.id === task.clientId);
              const priorityColors = { Low: 'text-blue-400 bg-blue-500/10', Medium: 'text-yellow-400 bg-yellow-500/10', High: 'text-red-400 bg-red-500/10' };
              return (
                <div key={task.id} className="flex items-center gap-4 p-3 bg-white/[0.03] hover:bg-white/5 rounded-xl transition-all border border-transparent hover:border-white/5">
                  <div className={`text-[9px] font-bold uppercase px-2 py-1 rounded-lg shrink-0 ${priorityColors[task.priority]}`}>
                    {task.priority}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{task.title}</p>
                    <p className="text-xs text-white/30">{client?.company || '—'}</p>
                  </div>
                  <div className="shrink-0">
                    <span className="text-[10px] bg-white/5 px-2 py-1 rounded-lg text-white/40">{task.status}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Sectors */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.4 }}
          className="lg:col-span-2 card p-6"
        >
          <h3 className="font-display font-bold text-lg mb-5 flex items-center gap-2">
            <TrendingUp size={18} className="text-brand" />
            Demandas por Setor
          </h3>
          {tasksBySector.length === 0 ? (
            <p className="text-white/20 text-sm text-center py-8">Sem dados</p>
          ) : (
            <div className="space-y-3">
              {tasksBySector.slice(0, 6).map((s, i) => {
                const maxCount = tasksBySector[0].count;
                const pct = Math.round((s.count / maxCount) * 100);
                return (
                  <div key={s.name}>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-white/60 font-medium truncate">{s.name}</span>
                      <span className="text-white/30 ml-2 shrink-0">{s.count}</span>
                    </div>
                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ delay: 0.5 + i * 0.05, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                        className="h-full bg-brand rounded-full"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="mt-6 pt-5 border-t border-bg-border">
            <h4 className="text-xs text-white/30 uppercase font-bold tracking-widest mb-3">Colaboradores</h4>
            <div className="space-y-2">
              {collaborators.slice(0, 4).map(c => (
                <div key={c.id} className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-full bg-brand/[0.15] border border-brand/20 flex items-center justify-center text-brand text-[10px] font-bold shrink-0">
                    {c.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-medium truncate">{c.name}</p>
                    <p className="text-[10px] text-white/30 truncate">{c.sector}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
