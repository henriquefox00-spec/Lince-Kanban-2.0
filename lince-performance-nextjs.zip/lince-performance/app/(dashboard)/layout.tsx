'use client';

import { useApp } from '@/context/AppContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import Sidebar from '@/components/layout/Sidebar';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { state, dispatch } = useApp();
  const router = useRouter();

  useEffect(() => {
    if (!state.loading && !state.currentUser) {
      router.replace('/');
    }
  }, [state.loading, state.currentUser, router]);

  if (state.loading) {
    return (
      <div className="min-h-screen bg-bg-dark flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 rounded-full border-2 border-brand border-t-transparent animate-spin" />
          <p className="text-white/30 text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!state.currentUser) return null;

  const handleLogout = () => {
    dispatch({ type: 'SET_CURRENT_USER', payload: null });
    router.push('/');
  };

  return (
    <div className="flex h-screen bg-bg-dark overflow-hidden">
      <Sidebar currentUser={state.currentUser} onLogout={handleLogout} />
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
