'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, Search, RotateCcw, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { PRIORITY_STYLES, formatDate } from '@/lib/utils';

export default function CompletedPage() {
  const { state, dispatch } = useApp();
  const { tasks, clients, collaborators, boards } = state;
  const [search, setSearch] = useState('');
  const [filterClient, setFilterClient] = useState('all');

  const lastBoardName = boards.length > 0 ? boards[boards.length - 1].name : 'Done';
  const completed = tasks.filter(t => t.isArchived || t.status === lastBoardName);

  const filtered = completed.filter(t => {
    const client = clients.find(c => c.id === t.clientId);
    const matchSearch = search === '' ||
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      (client?.company || '').toLowerCase().includes(search.toLowerCase());
    const matchClient = filterClient === 'all' || t.clientId === filterClient;
    return matchSearch && matchClient;
  });

  const handleRestore = async (taskId: string) => {
    const firstBoard = boards[0]?.name || 'To Do';
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isArchived: false, status: firstBoard }),
      });
      dispatch({ type: 'UPDATE_TASK', payload: { ...tasks.find(t => t.id === taskId)!, isArchived: false, status: firstBoard } });
    } catch (e) { console.error(e); }
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Histórico de Demandas</h2>
          <p className="text-white/30 text-sm">{completed.length} demanda{completed.length !== 1 ? 's' : ''} finalizada{completed.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..." className="bg-white/5 border border-bg-border rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-brand/50 transition-all w-48 placeholder:text-white/20" />
          </div>
          <select value={filterClient} onChange={e => setFilterClient(e.target.value)} className="bg-white/5 border border-bg-border rounded-xl px-3 py-2.5 text-sm focus:outline-none text-white/70">
            <option value="all">Todos os Clientes</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.company}</option>)}
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-24 border border-dashed border-white/10 rounded-3xl">
          <CheckCircle2 size={40} className="text-white/10 mx-auto mb-3" />
          <p className="text-white/20">Nenhuma demanda finalizada</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((task, i) => {
            const client = clients.find(c => c.id === task.clientId);
            const taskCollabs = collaborators.filter(c => task.collaboratorIds?.includes(c.id));
            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="card p-5 hover:border-white/10 transition-all flex items-center gap-5"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <CheckCircle2 size={18} className="text-emerald-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm mb-0.5 truncate">{task.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-white/40">
                    <span>{client?.company || '—'}</span>
                    {task.sectors.length > 0 && (
                      <span className="flex gap-1">
                        {task.sectors.slice(0, 2).map(s => <span key={s} className="bg-white/5 px-1.5 py-0.5 rounded">{s}</span>)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-md ${PRIORITY_STYLES[task.priority]}`}>
                    {task.priority}
                  </span>
                  <div className="flex -space-x-1.5">
                    {taskCollabs.slice(0, 3).map(c => (
                      <div key={c.id} title={c.name} className="w-6 h-6 rounded-full bg-brand/20 border-2 border-bg-card flex items-center justify-center text-[8px] font-bold text-brand">
                        {c.name.charAt(0)}
                      </div>
                    ))}
                  </div>
                  <span className="flex items-center gap-1.5 text-xs text-white/30">
                    <Calendar size={11} />
                    {formatDate(task.createdAt)}
                  </span>
                  <button
                    onClick={() => handleRestore(task.id)}
                    title="Restaurar"
                    className="p-2 text-white/20 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-xl transition-all"
                  >
                    <RotateCcw size={14} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
