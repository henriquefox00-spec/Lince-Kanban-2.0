'use client';

import { useState, useCallback } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, Settings2, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Modal from '@/components/ui/Modal';
import ConfirmModal from '@/components/ui/ConfirmModal';
import TaskCard from '@/components/kanban/TaskCard';
import TaskDetailModal from '@/components/kanban/TaskDetailModal';
import TaskFormModal from '@/components/kanban/TaskFormModal';
import type { Task, Board } from '@/lib/types';
import { generateId } from '@/lib/utils';

export default function KanbanPage() {
  const { state, dispatch } = useApp();
  const { tasks, clients, collaborators, boards, sectors, currentUser } = state;

  const [search, setSearch] = useState('');
  const [filterSector, setFilterSector] = useState('all');
  const [filterClient, setFilterClient] = useState('all');

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isBoardModalOpen, setIsBoardModalOpen] = useState(false);
  const [editingBoard, setEditingBoard] = useState<Board | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);

  const activeTasks = tasks.filter(t => !t.isArchived);

  const filtered = activeTasks.filter(t => {
    const matchSearch = search === '' || t.title.toLowerCase().includes(search.toLowerCase());
    const matchSector = filterSector === 'all' || t.sectors.includes(filterSector);
    const matchClient = filterClient === 'all' || t.clientId === filterClient;
    return matchSearch && matchSector && matchClient;
  });

  const moveTask = useCallback(async (taskId: string, newStatus: string) => {
    dispatch({ type: 'UPDATE_TASK', payload: { ...tasks.find(t => t.id === taskId)!, status: newStatus } });
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, collaboratorIds: tasks.find(t => t.id === taskId)?.collaboratorIds || [] }),
      });
    } catch (e) { console.error(e); }
  }, [tasks, dispatch]);

  const handleAddBoard = async (name: string) => {
    const board: Board = { id: generateId(), name, position: boards.length, createdAt: new Date().toISOString() };
    try {
      const res = await fetch('/api/boards', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(board),
      });
      if (res.ok) { dispatch({ type: 'ADD_BOARD', payload: board }); setIsBoardModalOpen(false); }
    } catch (e) { console.error(e); }
  };

  const handleUpdateBoard = async () => {
    if (!editingBoard) return;
    try {
      await fetch(`/api/boards/${editingBoard.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: editingBoard.name }),
      });
      dispatch({ type: 'UPDATE_BOARD', payload: editingBoard });
      setEditingBoard(null);
    } catch (e) { console.error(e); }
  };

  const handleDeleteBoard = (id: string) => {
    setConfirm({
      title: 'Excluir Quadro',
      message: 'Tem certeza? As tasks nele perderão o status visível.',
      onConfirm: async () => {
        await fetch(`/api/boards/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_BOARD', payload: id });
        setEditingBoard(null);
      },
    });
  };

  const [newBoardName, setNewBoardName] = useState('');

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="px-8 py-6 border-b border-bg-border flex items-center gap-4 shrink-0">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight">Kanban</h2>
          <p className="text-white/30 text-xs mt-0.5">{activeTasks.length} demanda{activeTasks.length !== 1 ? 's' : ''} ativa{activeTasks.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-3 ml-auto">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar demanda..."
              className="bg-white/5 border border-bg-border rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-brand/50 transition-all w-48 placeholder:text-white/20"
            />
          </div>
          <select
            value={filterSector}
            onChange={e => setFilterSector(e.target.value)}
            className="bg-white/5 border border-bg-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-brand/50 transition-all text-white/70"
          >
            <option value="all">Todos os Setores</option>
            {sectors.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
          </select>
          <select
            value={filterClient}
            onChange={e => setFilterClient(e.target.value)}
            className="bg-white/5 border border-bg-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-brand/50 transition-all text-white/70"
          >
            <option value="all">Todos os Clientes</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.company}</option>)}
          </select>
          {currentUser?.isAdmin && (
            <button onClick={() => setIsBoardModalOpen(true)} className="btn-ghost flex items-center gap-2 text-sm">
              <Settings2 size={16} />
            </button>
          )}
          <button onClick={() => setIsTaskModalOpen(true)} className="btn-brand flex items-center gap-2 text-sm">
            <Plus size={16} />
            Nova Demanda
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="flex-1 overflow-x-auto">
        <div className="flex gap-5 h-full p-6 min-w-max">
          {boards.map((board, bi) => {
            const boardTasks = filtered.filter(t => t.status === board.name);
            return (
              <motion.div
                key={board.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: bi * 0.06 }}
                className="flex flex-col w-72 shrink-0"
              >
                {/* Column header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-2 h-2 rounded-full bg-brand/60" />
                    <span className="font-display font-bold text-sm">{board.name}</span>
                    <span className="text-[10px] bg-white/[0.08] px-2 py-0.5 rounded-full text-white/40 font-medium">
                      {boardTasks.length}
                    </span>
                  </div>
                  {currentUser?.isAdmin && (
                    <button
                      onClick={() => setEditingBoard(board)}
                      className="text-white/[0.15] hover:text-white/50 transition-colors p-1"
                    >
                      <Settings2 size={13} />
                    </button>
                  )}
                </div>

                {/* Cards */}
                <div className="flex-1 space-y-3 overflow-y-auto pb-4">
                  <AnimatePresence>
                    {boardTasks.map(task => {
                      const client = clients.find(c => c.id === task.clientId);
                      const taskCollabs = collaborators.filter(c => task.collaboratorIds?.includes(c.id));
                      return (
                        <TaskCard
                          key={task.id}
                          task={task}
                          clientName={client?.company || '—'}
                          collaborators={taskCollabs}
                          statuses={boards.map(b => b.name)}
                          onClick={() => setSelectedTask(task)}
                          onMove={moveTask}
                        />
                      );
                    })}
                  </AnimatePresence>
                  {boardTasks.length === 0 && (
                    <div className="border border-dashed border-white/8 rounded-2xl py-8 text-center">
                      <p className="text-white/20 text-xs">Vazio</p>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Modals */}
      <TaskFormModal isOpen={isTaskModalOpen} onClose={() => setIsTaskModalOpen(false)} />

      <Modal isOpen={isBoardModalOpen} onClose={() => setIsBoardModalOpen(false)} title="Novo Quadro">
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nome do Quadro</label>
            <input
              type="text" value={newBoardName} onChange={e => setNewBoardName(e.target.value)}
              className="input-base" placeholder="Ex: Em Teste"
            />
          </div>
          <button onClick={() => { handleAddBoard(newBoardName); setNewBoardName(''); }} className="btn-brand w-full py-3.5">
            Criar Quadro
          </button>
        </div>
      </Modal>

      <Modal isOpen={!!editingBoard} onClose={() => setEditingBoard(null)} title="Editar Quadro">
        {editingBoard && (
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Nome</label>
              <input
                type="text" value={editingBoard.name}
                onChange={e => setEditingBoard({ ...editingBoard, name: e.target.value })}
                className="input-base"
              />
            </div>
            <div className="flex gap-3">
              <button onClick={() => handleDeleteBoard(editingBoard.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-semibold py-3.5 rounded-xl transition-all text-sm">
                Excluir
              </button>
              <button onClick={handleUpdateBoard} className="flex-[2] btn-brand py-3.5">
                Salvar
              </button>
            </div>
          </div>
        )}
      </Modal>

      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
          onMove={moveTask}
        />
      )}

      <AnimatePresence>
        {confirm && (
          <ConfirmModal
            isOpen={!!confirm}
            onClose={() => setConfirm(null)}
            onConfirm={confirm.onConfirm}
            title={confirm.title}
            message={confirm.message}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
