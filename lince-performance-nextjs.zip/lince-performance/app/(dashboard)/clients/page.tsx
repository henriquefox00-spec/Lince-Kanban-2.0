'use client';

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Plus, MoreVertical, Search, Building2, Mail } from 'lucide-react';
import { motion } from 'motion/react';
import Modal from '@/components/ui/Modal';
import ConfirmModal from '@/components/ui/ConfirmModal';
import type { Client } from '@/lib/types';
import { generateId, formatDate } from '@/lib/utils';

export default function ClientsPage() {
  const { state, dispatch } = useApp();
  const { clients, tasks } = state;
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
  const [form, setForm] = useState<Partial<Client>>({ name: '', company: '', email: '', status: 'Active' });

  const filtered = clients.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.company.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = async () => {
    if (!form.name?.trim() || !form.company?.trim()) { alert('Preencha nome e empresa.'); return; }
    const client: Client = { ...form as Client, id: generateId(), createdAt: new Date().toISOString() };
    try {
      const res = await fetch('/api/clients', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(client) });
      if (res.ok) { dispatch({ type: 'ADD_CLIENT', payload: client }); setIsModalOpen(false); setForm({ name: '', company: '', email: '', status: 'Active' }); }
    } catch (e) { console.error(e); }
  };

  const handleUpdate = async () => {
    if (!editingClient) return;
    try {
      await fetch(`/api/clients/${editingClient.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editingClient) });
      dispatch({ type: 'UPDATE_CLIENT', payload: editingClient });
      setEditingClient(null);
    } catch (e) { console.error(e); }
  };

  const handleDelete = (id: string) => {
    setConfirm({
      title: 'Excluir Cliente',
      message: 'Tem certeza? Todas as tarefas associadas serão apagadas.',
      onConfirm: async () => {
        await fetch(`/api/clients/${id}`, { method: 'DELETE' });
        dispatch({ type: 'DELETE_CLIENT', payload: id });
        setMenuOpen(null);
      },
    });
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight mb-1">Clientes</h2>
          <p className="text-white/30 text-sm">{clients.length} cliente{clients.length !== 1 ? 's' : ''} cadastrado{clients.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..." className="bg-white/5 border border-bg-border rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-brand/50 transition-all w-48 placeholder:text-white/20" />
          </div>
          <button onClick={() => setIsModalOpen(true)} className="btn-brand flex items-center gap-2 text-sm">
            <Plus size={16} /> Novo Cliente
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((client, i) => {
          const clientTaskCount = tasks.filter(t => t.clientId === client.id && !t.isArchived).length;
          return (
            <motion.div
              key={client.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="card p-5 hover:border-white/10 transition-all group relative"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-brand/10 border border-brand/[0.15] flex items-center justify-center">
                  <Building2 size={18} className="text-brand" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${client.status === 'Active' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/10 text-white/30'}`}>
                    {client.status === 'Active' ? 'Ativo' : 'Inativo'}
                  </span>
                  <div className="relative">
                    <button onClick={() => setMenuOpen(menuOpen === client.id ? null : client.id)} className="text-white/[0.15] hover:text-white/50 p-1 rounded-lg transition-all opacity-0 group-hover:opacity-100">
                      <MoreVertical size={14} />
                    </button>
                    {menuOpen === client.id && (
                      <div className="absolute right-0 mt-1 w-36 bg-bg-card border border-bg-border rounded-xl shadow-card z-20 py-1.5">
                        <button onClick={() => { setEditingClient(client); setMenuOpen(null); }} className="w-full text-left px-4 py-2 text-xs hover:bg-white/5 transition-colors">Editar</button>
                        <button onClick={() => handleDelete(client.id)} className="w-full text-left px-4 py-2 text-xs text-red-400 hover:bg-red-500/10 transition-colors">Excluir</button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <h3 className="font-display font-bold text-base mb-0.5">{client.company}</h3>
              <p className="text-sm text-white/40 mb-4">{client.name}</p>
              <div className="flex items-center justify-between text-xs text-white/30">
                <span className="flex items-center gap-1.5"><Mail size={11} />{client.email || '—'}</span>
                <span className="bg-white/5 px-2 py-0.5 rounded-full">{clientTaskCount} demanda{clientTaskCount !== 1 ? 's' : ''}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Cliente">
        <div className="space-y-4">
          {[{ label: 'Empresa *', key: 'company', placeholder: 'Nome da empresa' }, { label: 'Nome do Contato *', key: 'name', placeholder: 'Nome completo' }, { label: 'E-mail', key: 'email', placeholder: 'email@empresa.com' }].map(f => (
            <div key={f.key}>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">{f.label}</label>
              <input type="text" value={(form as Record<string, string>)[f.key] || ''} onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))} className="input-base" placeholder={f.placeholder} />
            </div>
          ))}
          <div>
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as 'Active' | 'Inactive' }))} className="input-base">
              <option value="Active">Ativo</option>
              <option value="Inactive">Inativo</option>
            </select>
          </div>
          <button onClick={handleAdd} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Cadastrar Cliente</button>
        </div>
      </Modal>

      <Modal isOpen={!!editingClient} onClose={() => setEditingClient(null)} title="Editar Cliente">
        {editingClient && (
          <div className="space-y-4">
            {[{ label: 'Empresa', key: 'company' }, { label: 'Nome do Contato', key: 'name' }, { label: 'E-mail', key: 'email' }].map(f => (
              <div key={f.key}>
                <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">{f.label}</label>
                <input type="text" value={(editingClient as Record<string, string>)[f.key] || ''} onChange={e => setEditingClient(c => c ? { ...c, [f.key]: e.target.value } : c)} className="input-base" />
              </div>
            ))}
            <div>
              <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2">Status</label>
              <select value={editingClient.status} onChange={e => setEditingClient(c => c ? { ...c, status: e.target.value as 'Active' | 'Inactive' } : c)} className="input-base">
                <option value="Active">Ativo</option>
                <option value="Inactive">Inativo</option>
              </select>
            </div>
            <button onClick={handleUpdate} className="btn-brand w-full py-4 font-display uppercase tracking-widest text-sm">Salvar Alterações</button>
          </div>
        )}
      </Modal>

      {confirm && <ConfirmModal isOpen onClose={() => setConfirm(null)} onConfirm={confirm.onConfirm} title={confirm.title} message={confirm.message} />}
    </div>
  );
}
