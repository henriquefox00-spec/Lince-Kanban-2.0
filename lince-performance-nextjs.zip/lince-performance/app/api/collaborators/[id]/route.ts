import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';
import bcrypt from 'bcryptjs';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const updates = await req.json();
    const allowed = ['name', 'email', 'sector', 'role', 'isAdmin', 'username', 'password', 'mustChangePassword'];
    const fields = Object.keys(updates).filter(k => allowed.includes(k));
    if (!fields.length) return NextResponse.json({ success: true });

    const updateData: Record<string, unknown> = {};
    for (const f of fields) {
      if (f === 'isAdmin' || f === 'mustChangePassword') updateData[f] = !!updates[f];
      else if (f === 'password' && updates[f]) updateData[f] = await bcrypt.hash(updates[f], 10);
      else updateData[f] = updates[f];
    }

    const { data, error } = await getSupabase().from('collaborators').update(updateData).eq('id', id).select().single();
    if (error) throw error;
    const { password: _, ...safe } = data as any;
    emit('collaborator:updated', { ...safe, isAdmin: !!safe.isAdmin });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { error } = await getSupabase().from('collaborators').delete().eq('id', id);
    if (error) throw error;
    emit('collaborator:deleted', id);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
