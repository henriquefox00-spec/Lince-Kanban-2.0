import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';
import bcrypt from 'bcryptjs';

export async function GET() {
  try {
    const { data, error } = await getSupabase().from('collaborators').select('*');
    if (error) throw error;
    const safe = (data || []).map(({ password, ...rest }: any) => ({ ...rest, isAdmin: !!rest.isAdmin }));
    return NextResponse.json(safe);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, name, email, sector, role, isAdmin, username, password, createdAt } = body;
    const hashed = password ? await bcrypt.hash(password, 10) : null;
    const { error } = await getSupabase().from('collaborators').insert([{
      id, name, email, sector, role,
      isAdmin: !!isAdmin, username,
      password: hashed,
      mustChangePassword: true,
      createdAt,
    }]);
    if (error) throw error;
    const newCollab = { id, name, email, sector, role, isAdmin: !!isAdmin, username, mustChangePassword: true, createdAt };
    emit('collaborator:created', newCollab);
    return NextResponse.json({ id }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
