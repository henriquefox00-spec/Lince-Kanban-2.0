import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function GET() {
  try {
    const { data, error } = await getSupabase().from('panels').select('*').order('createdAt', { ascending: false });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, name, collaboratorId, createdAt } = body;
    const { error } = await getSupabase().from('panels').insert([{ id, name, collaboratorId, createdAt }]);
    if (error) throw error;
    emit('panel:created', { id, name, collaboratorId, createdAt });
    return NextResponse.json({ id }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
