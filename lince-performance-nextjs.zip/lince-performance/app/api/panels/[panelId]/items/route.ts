import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ panelId: string }> }) {
  try {
    const { panelId } = await params;
    const { data, error } = await getSupabase()
      .from('panel_items').select('*').eq('panelId', panelId).order('position', { ascending: true });
    if (error) throw error;
    const items = (data || []).map((i: any) => ({
      ...i,
      isArchived: !!i.isArchived,
      isCompleted: !!i.isCompleted,
      checklist: typeof i.checklist === 'string' ? i.checklist : JSON.stringify(i.checklist || []),
      collaboratorIds: typeof i.collaboratorIds === 'string' ? JSON.parse(i.collaboratorIds) : (i.collaboratorIds || []),
    }));
    return NextResponse.json(items);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ panelId: string }> }) {
  try {
    const { panelId } = await params;
    const body = await req.json();
    const { id, type, title, content, checklist, collaboratorIds, position, createdAt } = body;
    const { error } = await getSupabase().from('panel_items').insert([{
      id, panelId, type, title, content,
      checklist: checklist || '[]',
      collaboratorIds: collaboratorIds || [],
      position, isArchived: false, isCompleted: false, createdAt,
    }]);
    if (error) throw error;
    const newItem = { id, panelId, type, title, content, checklist: checklist || '[]', collaboratorIds: collaboratorIds || [], position, isArchived: false, isCompleted: false, createdAt };
    emit('panel_item:created', newItem);
    return NextResponse.json({ id }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
