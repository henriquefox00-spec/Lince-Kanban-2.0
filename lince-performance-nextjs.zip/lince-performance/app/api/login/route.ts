import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const { username: rawUsername, password } = await req.json();
    const username = rawUsername?.trim();
    const supabase = getSupabase();

    let user, error;
    if (username === 'admin') {
      ({ data: user, error } = await supabase.from('collaborators').select('*').eq('id', 'admin-master').maybeSingle());
    } else {
      ({ data: user, error } = await supabase.from('collaborators').select('*').eq('username', username).limit(1).maybeSingle());
    }

    if (error || !user) return NextResponse.json({ error: 'Usuário ou senha incorretos' }, { status: 401 });
    if (!user.password) return NextResponse.json({ error: 'Usuário ou senha incorretos' }, { status: 401 });

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) return NextResponse.json({ error: 'Usuário ou senha incorretos' }, { status: 401 });

    const { password: _, ...safeUser } = user;
    return NextResponse.json({ user: { ...safeUser, isAdmin: !!user.isAdmin } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
