import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const updates = await req.json();
    const allowed = ['name', 'position'];
    const updateData: Record<string, unknown> = {};
    Object.keys(updates).filter(k => allowed.includes(k)).forEach(k => { updateData[k] = updates[k]; });
    const { data, error } = await getSupabase().from('boards').update(updateData).eq('id', id).select().single();
    if (error) throw error;
    emit('board:updated', data);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { error } = await getSupabase().from('boards').delete().eq('id', id);
    if (error) throw error;
    emit('board:deleted', id);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
