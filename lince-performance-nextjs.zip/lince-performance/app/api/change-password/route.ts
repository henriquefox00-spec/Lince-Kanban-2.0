import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const { userId, newPassword } = await req.json();
    const hashed = await bcrypt.hash(newPassword, 10);
    const { data, error } = await getSupabase()
      .from('collaborators')
      .update({ password: hashed, mustChangePassword: false })
      .eq('id', userId)
      .select()
      .single();
    if (error) throw error;
    const { password: _, ...safeUser } = data;
    return NextResponse.json({ user: { ...safeUser, isAdmin: !!data.isAdmin } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
