import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function GET() {
  try {
    const { data, error } = await getSupabase().from('sectors').select('*').order('name', { ascending: true });
    if (error) throw error;
    return NextResponse.json(data || []);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { error } = await getSupabase().from('sectors').insert([body]);
    if (error) throw error;
    emit('sector:created', body);
    return NextResponse.json({ id: body.id }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
