import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const updates = await req.json();
    const allowed = ['title', 'content', 'checklist', 'collaboratorIds', 'position', 'isArchived', 'isCompleted'];
    const fields = Object.keys(updates).filter(k => allowed.includes(k));

    if (fields.length > 0) {
      const updateData: Record<string, unknown> = {};
      fields.forEach(f => {
        if (f === 'isArchived' || f === 'isCompleted') updateData[f] = !!updates[f];
        else updateData[f] = updates[f];
      });
      await getSupabase().from('panel_items').update(updateData).eq('id', id);
    }

    const { data: item, error } = await getSupabase().from('panel_items').select('*').eq('id', id).single();
    if (error) throw error;
    emit('panel_item:updated', {
      ...item,
      isArchived: !!item.isArchived,
      isCompleted: !!item.isCompleted,
      checklist: typeof item.checklist === 'string' ? item.checklist : JSON.stringify(item.checklist || []),
      collaboratorIds: typeof item.collaboratorIds === 'string' ? JSON.parse(item.collaboratorIds) : (item.collaboratorIds || []),
    });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { error } = await getSupabase().from('panel_items').delete().eq('id', id);
    if (error) throw error;
    emit('panel_item:deleted', id);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
