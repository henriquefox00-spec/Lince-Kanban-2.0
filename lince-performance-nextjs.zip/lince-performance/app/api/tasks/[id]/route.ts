import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const updates = await req.json();
    const allowed = ['title', 'status', 'priority', 'description', 'sectors', 'collaboratorIds', 'isArchived', 'completedAt'];
    const updateData: Record<string, unknown> = {};

    Object.keys(updates).filter(k => allowed.includes(k)).forEach(k => {
      if (k === 'isArchived') updateData[k] = !!updates[k];
      else if (k === 'sectors' || k === 'collaboratorIds') updateData[k] = JSON.stringify(updates[k] || []);
      else updateData[k] = updates[k];
    });

    if (updates.status !== undefined && updates.status) {
      updateData.completedAt = undefined;
    }

    const { data: task, error } = await getSupabase().from('tasks').update(updateData).eq('id', id).select().single();
    if (error) throw error;

    const parsedCollabs = typeof task.collaboratorIds === 'string'
      ? JSON.parse(task.collaboratorIds) : (task.collaboratorIds || []);

    const updatedTask = {
      ...task,
      sectors: typeof task.sectors === 'string' ? JSON.parse(task.sectors) : (task.sectors || []),
      collaboratorIds: parsedCollabs,
      isArchived: !!task.isArchived,
    };

    // Log task history on status change
    if (updates.status !== undefined && parsedCollabs.length > 0) {
      const now = new Date().toISOString();
      const historyEntries = parsedCollabs.map((cId: string) => ({
        taskId: id, collaboratorId: cId, status: updates.status, timestamp: now,
      }));
      await getSupabase().from('task_history').insert(historyEntries);
    }

    emit('task:updated', updatedTask);

    // Check if task reached last board → emit finished
    const { data: lastBoard } = await getSupabase().from('boards').select('name').order('position', { ascending: false }).limit(1).single();
    if (lastBoard && updates.status === lastBoard.name) {
      const { data: history } = await getSupabase().from('task_history').select('*').eq('taskId', id).order('timestamp', { ascending: true });
      const { data: client } = await getSupabase().from('clients').select('*').eq('id', task.clientId).single();
      emit('task:finished', { task: { ...updatedTask, clientName: client?.company }, history: history || [] });
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { error } = await getSupabase().from('tasks').delete().eq('id', id);
    if (error) throw error;
    emit('task:deleted', id);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
