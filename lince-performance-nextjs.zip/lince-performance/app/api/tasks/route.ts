import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
import { emit } from '@/lib/socket-server';

export async function GET() {
  try {
    const { data, error } = await getSupabase().from('tasks').select('*').order('createdAt', { ascending: false });
    if (error) throw error;
    const tasks = (data || []).map((t: any) => ({
      ...t,
      sectors: typeof t.sectors === 'string' ? JSON.parse(t.sectors) : (t.sectors || []),
      collaboratorIds: typeof t.collaboratorIds === 'string' ? JSON.parse(t.collaboratorIds) : (t.collaboratorIds || []),
      isArchived: !!t.isArchived,
    }));
    return NextResponse.json(tasks);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const task = {
      ...body,
      sectors: JSON.stringify(body.sectors || []),
      collaboratorIds: JSON.stringify(body.collaboratorIds || []),
      isArchived: false,
    };
    const { error } = await getSupabase().from('tasks').insert([task]);
    if (error) throw error;
    const emitTask = { ...body, sectors: body.sectors || [], collaboratorIds: body.collaboratorIds || [], isArchived: false };
    emit('task:created', emitTask);
    return NextResponse.json({ id: body.id }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
