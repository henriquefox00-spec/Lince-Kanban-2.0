import { NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';

export async function POST() {
  try {
    const sb = getSupabase();
    await sb.from('tasks').delete().neq('id', '0');
    await sb.from('clients').delete().neq('id', '0');
    await sb.from('task_history').delete().neq('id', 0);
    await sb.from('panels').delete().neq('id', '0');
    await sb.from('panel_items').delete().neq('id', '0');
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
