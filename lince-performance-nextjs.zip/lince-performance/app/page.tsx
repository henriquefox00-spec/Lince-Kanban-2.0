'use client';

import { useApp } from '@/context/AppContext';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import LoginPage from '@/components/layout/LoginPage';

export default function Home() {
  const { state } = useApp();
  const router = useRouter();

  useEffect(() => {
    if (!state.loading && state.currentUser) {
      router.replace('/dashboard');
    }
  }, [state.loading, state.currentUser, router]);

  if (state.loading) {
    return (
      <div className="min-h-screen bg-bg-dark flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 rounded-full border-2 border-brand border-t-transparent animate-spin" />
          <p className="text-white/30 text-sm font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  if (state.currentUser) return null;

  return <LoginPage />;
}
