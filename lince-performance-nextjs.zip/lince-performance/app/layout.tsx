import type { Metadata } from 'next';
import './globals.css';
import { AppProvider } from '@/context/AppContext';
import ClientProviders from '@/components/layout/ClientProviders';

export const metadata: Metadata = {
  title: 'Lince Performance | Gestão de Demandas',
  description: 'Sistema de gestão de demandas e CRM exclusivo para a Lince Performance.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <AppProvider>
          <ClientProviders>
            {children}
          </ClientProviders>
        </AppProvider>
      </body>
    </html>
  );
}
