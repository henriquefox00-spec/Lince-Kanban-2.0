'use client';

import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import type { Task, Client, Collaborator, Board, Panel, PanelItem, SectorEntity } from '@/lib/types';

interface AppState {
  tasks: Task[];
  clients: Client[];
  collaborators: Collaborator[];
  boards: Board[];
  panels: Panel[];
  panelItems: PanelItem[];
  sectors: SectorEntity[];
  currentUser: Collaborator | null;
  loading: boolean;
  finishedTaskData: { task: Task & { clientName?: string }; history: unknown[] } | null;
}

type Action =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_CURRENT_USER'; payload: Collaborator | null }
  | { type: 'SET_ALL_DATA'; payload: Partial<AppState> }
  | { type: 'SET_TASKS'; payload: Task[] }
  | { type: 'SET_CLIENTS'; payload: Client[] }
  | { type: 'SET_COLLABORATORS'; payload: Collaborator[] }
  | { type: 'SET_BOARDS'; payload: Board[] }
  | { type: 'SET_PANELS'; payload: Panel[] }
  | { type: 'SET_PANEL_ITEMS'; payload: PanelItem[] }
  | { type: 'SET_SECTORS'; payload: SectorEntity[] }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK'; payload: Task }
  | { type: 'DELETE_TASK'; payload: string }
  | { type: 'ADD_CLIENT'; payload: Client }
  | { type: 'UPDATE_CLIENT'; payload: Client }
  | { type: 'DELETE_CLIENT'; payload: string }
  | { type: 'ADD_COLLABORATOR'; payload: Collaborator }
  | { type: 'UPDATE_COLLABORATOR'; payload: Collaborator }
  | { type: 'DELETE_COLLABORATOR'; payload: string }
  | { type: 'ADD_BOARD'; payload: Board }
  | { type: 'UPDATE_BOARD'; payload: Board }
  | { type: 'DELETE_BOARD'; payload: string }
  | { type: 'ADD_PANEL'; payload: Panel }
  | { type: 'UPDATE_PANEL'; payload: Panel }
  | { type: 'DELETE_PANEL'; payload: string }
  | { type: 'ADD_PANEL_ITEM'; payload: PanelItem }
  | { type: 'UPDATE_PANEL_ITEM'; payload: PanelItem }
  | { type: 'DELETE_PANEL_ITEM'; payload: string }
  | { type: 'ADD_SECTOR'; payload: SectorEntity }
  | { type: 'DELETE_SECTOR'; payload: string }
  | { type: 'SET_FINISHED_TASK'; payload: AppState['finishedTaskData'] };

const initialState: AppState = {
  tasks: [],
  clients: [],
  collaborators: [],
  boards: [],
  panels: [],
  panelItems: [],
  sectors: [],
  currentUser: null,
  loading: true,
  finishedTaskData: null,
};

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_LOADING': return { ...state, loading: action.payload };
    case 'SET_CURRENT_USER': return { ...state, currentUser: action.payload };
    case 'SET_ALL_DATA': return { ...state, ...action.payload };
    case 'SET_TASKS': return { ...state, tasks: action.payload };
    case 'SET_CLIENTS': return { ...state, clients: action.payload };
    case 'SET_COLLABORATORS': return { ...state, collaborators: action.payload };
    case 'SET_BOARDS': return { ...state, boards: action.payload };
    case 'SET_PANELS': return { ...state, panels: action.payload };
    case 'SET_PANEL_ITEMS': return { ...state, panelItems: action.payload };
    case 'SET_SECTORS': return { ...state, sectors: action.payload };
    case 'SET_FINISHED_TASK': return { ...state, finishedTaskData: action.payload };

    case 'ADD_TASK':
      if (state.tasks.find(t => t.id === action.payload.id)) return state;
      return { ...state, tasks: [...state.tasks, action.payload] };
    case 'UPDATE_TASK':
      return { ...state, tasks: state.tasks.map(t => t.id === action.payload.id ? action.payload : t) };
    case 'DELETE_TASK':
      return { ...state, tasks: state.tasks.filter(t => t.id !== action.payload) };

    case 'ADD_CLIENT':
      if (state.clients.find(c => c.id === action.payload.id)) return state;
      return { ...state, clients: [...state.clients, action.payload] };
    case 'UPDATE_CLIENT':
      return { ...state, clients: state.clients.map(c => c.id === action.payload.id ? { ...c, ...action.payload } : c) };
    case 'DELETE_CLIENT':
      return {
        ...state,
        clients: state.clients.filter(c => c.id !== action.payload),
        tasks: state.tasks.filter(t => t.clientId !== action.payload),
      };

    case 'ADD_COLLABORATOR':
      if (state.collaborators.find(c => c.id === action.payload.id)) return state;
      return { ...state, collaborators: [...state.collaborators, action.payload] };
    case 'UPDATE_COLLABORATOR':
      return { ...state, collaborators: state.collaborators.map(c => c.id === action.payload.id ? { ...c, ...action.payload } : c) };
    case 'DELETE_COLLABORATOR':
      return { ...state, collaborators: state.collaborators.filter(c => c.id !== action.payload) };

    case 'ADD_BOARD':
      if (state.boards.find(b => b.id === action.payload.id)) return state;
      return { ...state, boards: [...state.boards, action.payload].sort((a, b) => a.position - b.position) };
    case 'UPDATE_BOARD':
      return { ...state, boards: state.boards.map(b => b.id === action.payload.id ? action.payload : b).sort((a, b) => a.position - b.position) };
    case 'DELETE_BOARD':
      return { ...state, boards: state.boards.filter(b => b.id !== action.payload) };

    case 'ADD_PANEL':
      if (state.panels.find(p => p.id === action.payload.id)) return state;
      return { ...state, panels: [action.payload, ...state.panels] };
    case 'UPDATE_PANEL':
      return { ...state, panels: state.panels.map(p => p.id === action.payload.id ? action.payload : p) };
    case 'DELETE_PANEL':
      return { ...state, panels: state.panels.filter(p => p.id !== action.payload) };

    case 'ADD_PANEL_ITEM':
      if (state.panelItems.find(i => i.id === action.payload.id)) return state;
      return { ...state, panelItems: [...state.panelItems, action.payload].sort((a, b) => a.position - b.position) };
    case 'UPDATE_PANEL_ITEM':
      return { ...state, panelItems: state.panelItems.map(i => i.id === action.payload.id ? action.payload : i).sort((a, b) => a.position - b.position) };
    case 'DELETE_PANEL_ITEM':
      return { ...state, panelItems: state.panelItems.filter(i => i.id !== action.payload) };

    case 'ADD_SECTOR':
      if (state.sectors.find(s => s.id === action.payload.id)) return state;
      return { ...state, sectors: [...state.sectors, action.payload].sort((a, b) => a.name.localeCompare(b.name)) };
    case 'DELETE_SECTOR':
      return { ...state, sectors: state.sectors.filter(s => s.id !== action.payload) };

    default: return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<Action>;
} | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const fetchData = useCallback(async () => {
    try {
      const [tasksRes, clientsRes, collabsRes, boardsRes, panelsRes, sectorsRes] = await Promise.all([
        fetch('/api/tasks'),
        fetch('/api/clients'),
        fetch('/api/collaborators'),
        fetch('/api/boards'),
        fetch('/api/panels'),
        fetch('/api/sectors'),
      ]);
      const [tasks, clients, collaborators, boards, panels, sectors] = await Promise.all([
        tasksRes.json(),
        clientsRes.json(),
        collabsRes.json(),
        boardsRes.json(),
        panelsRes.json(),
        sectorsRes.json(),
      ]);
      dispatch({
        type: 'SET_ALL_DATA',
        payload: {
          tasks: Array.isArray(tasks) ? tasks : [],
          clients: Array.isArray(clients) ? clients : [],
          collaborators: Array.isArray(collaborators) ? collaborators : [],
          boards: Array.isArray(boards) ? boards : [],
          panels: Array.isArray(panels) ? panels : [],
          sectors: Array.isArray(sectors) ? sectors : [],
        },
      });
      const savedUser = localStorage.getItem('lince_current_user');
      if (savedUser) dispatch({ type: 'SET_CURRENT_USER', payload: JSON.parse(savedUser) });
    } catch (err) {
      console.error('Error fetching app data:', err);
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (state.currentUser) localStorage.setItem('lince_current_user', JSON.stringify(state.currentUser));
    else localStorage.removeItem('lince_current_user');
  }, [state.currentUser]);

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
