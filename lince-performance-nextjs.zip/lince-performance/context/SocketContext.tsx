'use client';

import React, { createContext, useContext, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import { useApp } from './AppContext';
import type { Task, Client, Collaborator, Board, Panel, PanelItem, SectorEntity } from '@/lib/types';

let socket: Socket | null = null;

function getSocket(): Socket {
  if (!socket) {
    socket = io({ path: '/socket.io' });
  }
  return socket;
}

const SocketContext = createContext<Socket | null>(null);

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const { dispatch } = useApp();

  useEffect(() => {
    const s = getSocket();

    s.on('task:created', (task: Task) => dispatch({ type: 'ADD_TASK', payload: task }));
    s.on('task:updated', (task: Task) => dispatch({ type: 'UPDATE_TASK', payload: task }));
    s.on('task:deleted', (id: string) => dispatch({ type: 'DELETE_TASK', payload: id }));
    s.on('task:finished', (data: { task: Task & { clientName?: string }; history: unknown[] }) => {
      dispatch({ type: 'SET_FINISHED_TASK', payload: data });
    });

    s.on('client:created', (client: Client) => dispatch({ type: 'ADD_CLIENT', payload: client }));
    s.on('client:updated', (client: Client) => dispatch({ type: 'UPDATE_CLIENT', payload: client }));
    s.on('client:deleted', (id: string) => dispatch({ type: 'DELETE_CLIENT', payload: id }));

    s.on('collaborator:created', (c: Collaborator) => dispatch({ type: 'ADD_COLLABORATOR', payload: c }));
    s.on('collaborator:updated', (c: Collaborator) => dispatch({ type: 'UPDATE_COLLABORATOR', payload: c }));
    s.on('collaborator:deleted', (id: string) => dispatch({ type: 'DELETE_COLLABORATOR', payload: id }));

    s.on('board:created', (b: Board) => dispatch({ type: 'ADD_BOARD', payload: b }));
    s.on('board:updated', (b: Board) => dispatch({ type: 'UPDATE_BOARD', payload: b }));
    s.on('board:deleted', (id: string) => dispatch({ type: 'DELETE_BOARD', payload: id }));

    s.on('sector:created', (sec: SectorEntity) => dispatch({ type: 'ADD_SECTOR', payload: sec }));
    s.on('sector:deleted', (id: string) => dispatch({ type: 'DELETE_SECTOR', payload: id }));

    s.on('panel:created', (p: Panel) => dispatch({ type: 'ADD_PANEL', payload: p }));
    s.on('panel:updated', (p: Panel) => dispatch({ type: 'UPDATE_PANEL', payload: p }));
    s.on('panel:deleted', (id: string) => dispatch({ type: 'DELETE_PANEL', payload: id }));

    s.on('panel_item:created', (i: PanelItem) => dispatch({ type: 'ADD_PANEL_ITEM', payload: i }));
    s.on('panel_item:updated', (i: PanelItem) => dispatch({ type: 'UPDATE_PANEL_ITEM', payload: i }));
    s.on('panel_item:deleted', (id: string) => dispatch({ type: 'DELETE_PANEL_ITEM', payload: id }));

    return () => {
      s.off('task:created'); s.off('task:updated'); s.off('task:deleted'); s.off('task:finished');
      s.off('client:created'); s.off('client:updated'); s.off('client:deleted');
      s.off('collaborator:created'); s.off('collaborator:updated'); s.off('collaborator:deleted');
      s.off('board:created'); s.off('board:updated'); s.off('board:deleted');
      s.off('sector:created'); s.off('sector:deleted');
      s.off('panel:created'); s.off('panel:updated'); s.off('panel:deleted');
      s.off('panel_item:created'); s.off('panel_item:updated'); s.off('panel_item:deleted');
    };
  }, [dispatch]);

  return <SocketContext.Provider value={getSocket()}>{children}</SocketContext.Provider>;
}

export function useSocket() {
  return useContext(SocketContext);
}
